#!/usr/bin/env python3
"""
Multi-Camera Audio Synchronization for DaVinci Resolve
Finds where each camera clip appears in the master recording via
sliding-window waveform cross-correlation.
"""

import json
import subprocess
import os
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from datetime import datetime, timezone
import re

try:
    import librosa
    import numpy as np
    from scipy.signal import correlate
    AUDIO_LIBS_AVAILABLE = True
except ImportError:
    AUDIO_LIBS_AVAILABLE = False
    librosa = None
    np = None
    correlate = None

# Resolve ffmpeg/ffprobe paths once at import time.
# On macOS, GUIs launched outside a terminal may not have /opt/homebrew/bin in PATH.
def _find_tool(name: str) -> str:
    found = shutil.which(name)
    if found:
        return found
    for candidate in [
        f"/opt/homebrew/bin/{name}",
        f"/usr/local/bin/{name}",
        f"/usr/bin/{name}",
    ]:
        if os.path.isfile(candidate):
            return candidate
    return name  # fallback: hope it's on PATH

FFMPEG_BIN  = _find_tool("ffmpeg")
FFPROBE_BIN = _find_tool("ffprobe")


# ── Constants ─────────────────────────────────────────────────────────────────

COARSE_SR             = 4000    # Hz – low-res for full-master scan
FINE_SR               = 22050   # Hz – high-res for sub-frame precision
CLIP_SKIP_SECS        = 2.0     # skip first N seconds of clip (motor/startup noise)
CLIP_SAMPLE_SECS      = 30.0    # seconds of clip audio used for matching
SEARCH_CHUNK_SECS     = 300.0   # master chunk size for coarse search (5 min)
SEARCH_CHUNK_STEP     = 270.0   # step between chunks (guarantees no clip falls in gap)
FINE_MARGIN_SECS      = 5.0     # ±N seconds around coarse match for fine-tuning


# ── Metadata helpers ───────────────────────────────────────────────────────────

def get_media_metadata(file_path: str) -> Dict:
    """Get creation time, duration, timecode from a media file using ffprobe."""
    meta = {
        "creation_time": None,
        "duration": 0.0,
        "timecode": None,
        "file_mtime": None,
    }

    try:
        stat = os.stat(file_path)
        meta["file_mtime"] = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)
    except Exception:
        pass

    try:
        result = subprocess.run(
            [
                FFPROBE_BIN, "-v", "quiet",
                "-print_format", "json",
                "-show_format", "-show_streams",
                file_path,
            ],
            capture_output=True, text=True, timeout=15
        )
        if result.returncode != 0:
            return meta

        data = json.loads(result.stdout)
        fmt = data.get("format", {})
        streams = data.get("streams", [])

        meta["duration"] = float(fmt.get("duration", 0) or 0)

        # Detect RAW formats based on file extension or format name
        ext = Path(file_path).suffix.lower()
        meta["is_raw"] = ext in ['.braw', '.r3d', '.ari', '.arx', '.crm']

        # Detect VFR (Variable Frame Rate)
        # 1. iPhones often tag themselves in the 'com.apple.quicktime.software' metadata
        # 2. R_frame_rate vs avg_frame_rate in video stream
        meta["is_vfr"] = False
        for s in streams:
            if s.get("codec_type") == "video":
                # Check Apple smartphones which heavily use VFR
                software = fmt.get("tags", {}).get("com.apple.quicktime.software", "")
                if "iPhone" in str(software):
                    meta["is_vfr"] = True
                
                # Check frame rate mismatch
                r_fps_str = s.get("r_frame_rate", "0/0")
                avg_fps_str = s.get("avg_frame_rate", "0/0")
                
                def parse_fps(fps_str):
                    try:
                        num, den = fps_str.split('/')
                        return float(num) / float(den) if float(den) != 0 else 0.0
                    except:
                        return 0.0
                        
                r_fps = parse_fps(r_fps_str)
                avg_fps = parse_fps(avg_fps_str)
                
                # If avg is significantly different from base (e.g. 29.98 vs 30.0), it's likely VFR
                if r_fps > 0 and avg_fps > 0 and abs(r_fps - avg_fps) > 0.05:
                    meta["is_vfr"] = True
                break

        ct_str = (
            fmt.get("tags", {}).get("creation_time") or
            next((s.get("tags", {}).get("creation_time")
                  for s in streams if s.get("tags", {}).get("creation_time")), None)
        )
        if ct_str:
            try:
                meta["creation_time"] = datetime.fromisoformat(ct_str.replace("Z", "+00:00"))
            except Exception:
                pass

        meta["timecode"] = (
            fmt.get("tags", {}).get("timecode") or
            next((s.get("tags", {}).get("timecode")
                  for s in streams if s.get("tags", {}).get("timecode")), None)
        )

    except FileNotFoundError:
        pass
    except Exception:
        pass

    return meta


# ── Audio loading helpers ──────────────────────────────────────────────────────

def load_audio_ffmpeg(
    file_path: str,
    start_sec: float = 0.0,
    duration_sec: Optional[float] = None,
    sr: int = FINE_SR,
) -> Optional["np.ndarray"]:
    """
    Extract a time segment from any media file (audio or video) using ffmpeg.
    Returns mono float32 array at the requested sample rate, or None on failure.
    """
    if not AUDIO_LIBS_AVAILABLE:
        return None

    import tempfile as tf_mod
    tmp_path = None
    try:
        with tf_mod.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
            tmp_path = tmp.name

        cmd = [FFMPEG_BIN, '-y', '-ss', str(start_sec), '-i', file_path,
               '-vn', '-ac', '1', '-ar', str(sr), '-acodec', 'pcm_s16le']
        if duration_sec is not None:
            cmd += ['-t', str(duration_sec)]
        cmd.append(tmp_path)

        r = subprocess.run(cmd, capture_output=True, timeout=120)
        if r.returncode != 0:
            return None

        y, _ = librosa.load(tmp_path, sr=sr, mono=True)
        return y
    except Exception:
        return None
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass


def load_audio_full(
    file_path: str,
    sr: int = COARSE_SR,
) -> Optional["np.ndarray"]:
    """
    Load the ENTIRE audio file at the given sample rate.
    Uses librosa directly for pure audio formats (fast), ffmpeg for video.
    """
    if not AUDIO_LIBS_AVAILABLE:
        return None

    ext = Path(file_path).suffix.lower()
    audio_exts = {'.wav', '.mp3', '.aiff', '.aif', '.m4a', '.flac', '.ogg'}

    if ext in audio_exts:
        try:
            y, _ = librosa.load(file_path, sr=sr, mono=True)
            return y
        except Exception:
            pass  # fall through to ffmpeg

    # Video files (or librosa failed)
    return load_audio_ffmpeg(file_path, 0.0, None, sr)


# ── Core sync function ─────────────────────────────────────────────────────────

def find_clip_position_in_master(
    clip_path: str,
    master_wave: "np.ndarray",    # master pre-loaded at master_sr
    master_path: str,             # only used for fine-tune (ffmpeg seek)
    master_sr: int = COARSE_SR,
    log_fn=None,
) -> Tuple[float, float]:
    """
    Find where in the master recording the clip's audio appears.

    Uses a two-pass approach:
      1. Coarse scan (COARSE_SR=4000 Hz): slide clip across in-memory master array
         in overlapping chunks → find approximate position.
      2. Fine-tune (FINE_SR=22050 Hz): load ±FINE_MARGIN seconds around the
         coarse match, re-correlate at full resolution → sub-frame accuracy.

    Returns
    -------
    (position_in_master_seconds, confidence)
        position_in_master_seconds:
            Where in the master file this clip's audio begins.
            Use as  record_frame = position * fps  when building the timeline.
        confidence:
            Normalised cross-correlation peak, 0..1.
            Values > 0.05 are usually a reliable match.
    """
    if not AUDIO_LIBS_AVAILABLE or master_wave is None or len(master_wave) == 0:
        return 0.0, 0.0

    def log(msg):
        if log_fn:
            log_fn(msg)

    # ── Load clip sample ──────────────────────────────────────────────────────
    clip_wave = load_audio_ffmpeg(
        clip_path,
        start_sec=CLIP_SKIP_SECS,
        duration_sec=CLIP_SAMPLE_SECS,
        sr=master_sr,
    )
    if clip_wave is None or len(clip_wave) < master_sr * 2:
        # Language-neutral diagnostic — the worker translates module-level
        # tags via TRANSLATIONS keys; here we keep it short and bilingual.
        log("     ⚠️  could not load clip audio / no se pudo cargar audio del clip")
        return 0.0, 0.0

    clip_norm = clip_wave / (np.max(np.abs(clip_wave)) + 1e-8)
    clip_len  = len(clip_norm)

    chunk_len = int(SEARCH_CHUNK_SECS * master_sr)
    step_len  = int(SEARCH_CHUNK_STEP * master_sr)

    best_sample = 0
    best_score  = -1.0
    master_len  = len(master_wave)

    # ── Coarse sliding-window search ──────────────────────────────────────────
    i = 0
    while True:
        start = i * step_len
        if start >= master_len:
            break

        chunk = master_wave[start: start + chunk_len]
        if len(chunk) < clip_len:
            break

        chunk_norm = chunk / (np.max(np.abs(chunk)) + 1e-8)

        # Full cross-correlation: corr[k] = similarity when clip starts at sample k in chunk
        corr = correlate(chunk_norm, clip_norm, mode='full')
        lags = np.arange(-(clip_len - 1), len(chunk_norm))

        # Only non-negative lags: clip starts at or after chunk start
        valid_mask = lags >= 0
        corr_v = np.abs(corr[valid_mask])
        lags_v = lags[valid_mask]

        if len(corr_v) == 0:
            i += 1
            continue

        idx = int(np.argmax(corr_v))
        lag = int(lags_v[idx])

        # Normalised score (≈ Pearson correlation coefficient)
        clip_rms  = float(np.sqrt(np.mean(clip_norm ** 2)))
        chunk_seg = chunk_norm[lag: lag + clip_len]
        if len(chunk_seg) < int(clip_len * 0.8):
            i += 1
            continue
        chunk_rms = float(np.sqrt(np.mean(chunk_seg ** 2)))
        denom     = clip_rms * chunk_rms * clip_len
        score     = float(corr_v[idx]) / (denom + 1e-8)

        abs_sample = start + lag
        if score > best_score:
            best_score  = score
            best_sample = abs_sample

        i += 1

    coarse_sec = best_sample / master_sr
    log(f"     📍  Coarse: {coarse_sec:.2f}s  (score={best_score:.4f})")

    # ── Fine-tune at full resolution ──────────────────────────────────────────
    if best_score > 0.003:   # any non-trivial match worth refining
        fine_start = max(0.0, coarse_sec - FINE_MARGIN_SECS)
        fine_dur   = FINE_MARGIN_SECS * 2 + CLIP_SAMPLE_SECS

        log(f"     🔬  Fine [{fine_start:.1f}s → {fine_start + fine_dur:.1f}s] @ {FINE_SR} Hz …")

        fine_master = load_audio_ffmpeg(master_path, fine_start, fine_dur, FINE_SR)
        fine_clip   = load_audio_ffmpeg(clip_path, CLIP_SKIP_SECS, CLIP_SAMPLE_SECS, FINE_SR)

        if fine_master is not None and fine_clip is not None and len(fine_master) > len(fine_clip):
            fm = fine_master / (np.max(np.abs(fine_master)) + 1e-8)
            fc = fine_clip   / (np.max(np.abs(fine_clip))   + 1e-8)

            corr = correlate(fm, fc, mode='full')
            lags = np.arange(-(len(fc) - 1), len(fm))

            valid_mask = lags >= 0
            corr_v = np.abs(corr[valid_mask])
            lags_v = lags[valid_mask]

            if len(corr_v) > 0:
                idx = int(np.argmax(corr_v))
                lag = int(lags_v[idx])

                fc_rms   = float(np.sqrt(np.mean(fc ** 2)))
                fm_seg   = fm[lag: lag + len(fc)]
                if len(fm_seg) >= int(len(fc) * 0.8):
                    fm_rms     = float(np.sqrt(np.mean(fm_seg ** 2)))
                    denom      = fc_rms * fm_rms * len(fc)
                    fine_score = float(corr_v[idx]) / (denom + 1e-8)
                    fine_pos   = fine_start + lag / FINE_SR

                    # ── CRITICAL OFFSET CORRECTION ────────────────────────
                    # We loaded the clip starting at CLIP_SKIP_SECS, so the
                    # correlation tells us where clip[CLIP_SKIP_SECS:] aligns
                    # in the master. The CLIP'S FIRST FRAME is therefore at
                    # (matched_position − CLIP_SKIP_SECS).
                    # Without this subtraction every waveform-placed clip
                    # lands CLIP_SKIP_SECS seconds late.
                    fine_pos -= CLIP_SKIP_SECS

                    log(f"     ✅  Fine:   {fine_pos:.3f}s  (score={fine_score:.4f})")
                    return fine_pos, fine_score

    # Same correction for the coarse-only path
    return coarse_sec - CLIP_SKIP_SECS, best_score


# ── Legacy helpers (kept for backward compatibility) ───────────────────────────

def load_waveform(file_path: str, max_seconds: int = 60) -> Optional["np.ndarray"]:
    """Legacy: load first max_seconds of audio. Use load_audio_ffmpeg for new code."""
    return load_audio_ffmpeg(file_path, 0.0, float(max_seconds), FINE_SR)


def waveform_correlation_score(
    cam_wave: "np.ndarray",
    master_wave: "np.ndarray",
) -> Tuple[float, float]:
    """
    Legacy: compare two equal-length waveforms (both from file start).
    Kept for callers that pre-loaded 60s windows.

    NOTE: for long recordings use find_clip_position_in_master instead.
    """
    if cam_wave is None or master_wave is None:
        return 0.0, 0.0

    SR = FINE_SR
    cam = cam_wave / (np.max(np.abs(cam_wave)) + 1e-8)
    mst = master_wave / (np.max(np.abs(master_wave)) + 1e-8)

    n_cam = min(len(cam), SR * 60)
    n_mst = min(len(mst), SR * 60)
    cam = cam[:n_cam]
    mst = mst[:n_mst]

    corr = correlate(mst, cam, mode="full")
    lags = np.arange(-(len(cam) - 1), len(mst))
    best_idx = int(np.argmax(np.abs(corr)))
    offset_sec = float(lags[best_idx]) / SR

    energy = np.sqrt(np.sum(cam ** 2) * np.sum(mst ** 2))
    confidence = float(np.abs(corr[best_idx]) / (energy + 1e-8))
    confidence = min(1.0, max(0.0, confidence))

    return offset_sec, confidence
