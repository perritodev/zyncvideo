#!/usr/bin/env python3
"""
Zync GUI - Multi-Camera Audio Synchronization Interface
Dark Mode | Dynamic DaVinci Timeline Loading
"""

import sys
import os
import json
from pathlib import Path
from typing import List, Dict

try:
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QTreeWidget, QTreeWidgetItem, QListWidget, QListWidgetItem,
        QPushButton, QLabel, QLineEdit, QSplitter,
        QMessageBox, QFileDialog, QScrollArea, QFrame
    )
    from PyQt5.QtCore import Qt, QThread, pyqtSignal
    from PyQt5.QtGui import QFont, QColor
    PYQT5_AVAILABLE = True
except ImportError:
    PYQT5_AVAILABLE = False
    print("❌ PyQt5 no está instalado")
    print("Instala con: pip3 install PyQt5")
    sys.exit(1)

sys.path.insert(0, str(Path(__file__).parent))

# --- PyInstaller Subprocess Interceptor ---
if getattr(sys, 'frozen', False) and "--bridge" in sys.argv:
    import davinci_bridge
    # Remove --bridge from argv so davinci_bridge can parse the rest normally
    idx = sys.argv.index("--bridge")
    sys.argv = [sys.argv[0]] + sys.argv[idx+1:]
    sys.exit(davinci_bridge.main())
# ------------------------------------------

# multi_camera_sync_mcp is imported inside SyncWorker.run() to avoid circular issues


# ═══════════════════════════════════════════════════════════════════════════
#  i18n — language toggle (Spanish ↔ English)
# ═══════════════════════════════════════════════════════════════════════════
# The user's chosen language is persisted to ~/.cinematic_sync/config.json
# so the GUI reopens in the same language.  Default is Spanish.

_CONFIG_DIR  = Path.home() / ".cinematic_sync"
_CONFIG_FILE = _CONFIG_DIR / "config.json"


def _load_config() -> dict:
    try:
        with open(_CONFIG_FILE) as f:
            return json.load(f) or {}
    except Exception:
        return {}


def _save_config(cfg: dict) -> None:
    try:
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(_CONFIG_FILE, "w") as f:
            json.dump(cfg, f, indent=2)
    except Exception:
        pass


# Module-level current language; loaded from config on import.
CURRENT_LANG = (_load_config().get("lang") or "es").lower()
if CURRENT_LANG not in ("es", "en"):
    CURRENT_LANG = "es"


# Master translation table.  EVERY user-visible string in the GUI lives here.
# Use `tr("key")` for a plain lookup or `tr("key", **kwargs)` for `.format()`.
TRANSLATIONS = {
    "es": {
        # ── Window / header / top bar ──────────────────────────────────
        "window_title":            "Zync",
        "header_title":            "Zync",
        "connecting":              "Conectando a DaVinci...",
        "btn_refresh":             "⟳ Actualizar",
        "btn_lang":                "🌐 EN",
        "btn_lang_tooltip":        "Cambiar a inglés",
        "davinci_not_connected":   "⚠️  DaVinci no conectado",
        "davinci_not_detected":    "⚠️  DaVinci no detectado",
        "davinci_open_hint":       "  Abre DaVinci con un proyecto y presiona ⟳",
        "davinci_connect_log":     "⚠️  No se pudo conectar a DaVinci.\nAsegúrate de tener un proyecto abierto y External Scripting habilitado.\nPresiona ⟳ Actualizar para reintentar.",

        # ── Left / right column titles ─────────────────────────────────
        "section_timelines":       "TIMELINES DE CÁMARAS",
        "section_audio_masters":   "AUDIO MAESTROS  (selecciona uno o varios)",
        "tree_header_timeline":    "Timeline",
        "tree_header_file":        "Archivo",
        "n_of_m_selected":         "{n}/{m} seleccionada(s)",
        "n_audios_in_project":     "{n} audio(s) del proyecto — marca los masters",
        "no_audio_found":          "  ⚠️  No se encontraron audios en: {path}",
        "no_project_path":         "  ⚠️  No se pudo detectar la ruta del proyecto",
        "press_refresh_with_open": "  → Presiona ⟳ Actualizar con DaVinci abierto",
        "use_browse_manual":       "Usa '📂 Agregar archivo...' para seleccionar manualmente",
        "select_one_or_more":      "Selecciona uno o varios audio masters",
        "n_masters_selected":      "✓  {n} audio master(s) seleccionado(s)",
        "audios_searching":        "Buscando audios...",
        "btn_browse":              "📂  Agregar archivo...",
        "browse_dialog_title":     "Seleccionar audio master(s)",
        "browse_filter":           "Audio (*.wav *.mp3 *.aiff *.aif *.m4a *.flac);;Todos (*)",
        "manual_group":            "📁  Manual",
        "n_timelines_loaded":      "✅  {n} timelines cargadas de '{name}'",

        # ── Bottom panel ───────────────────────────────────────────────
        "output_timeline":         "Timeline de salida:",
        "ready_to_sync":           "✅  Listo para sincronizar",
        "btn_sync":                "▶   SINCRONIZAR",
        "btn_clear":               "↺  Limpiar",
        "btn_exit":                "✕  Salir",
        "default_out_name":        "ZYNC_FINAL_SYNC",

        # ── Dialogs ────────────────────────────────────────────────────
        "dlg_no_selection_title":  "Sin selección",
        "dlg_no_selection_body":   "Selecciona al menos una timeline.",
        "dlg_no_master_title":     "Sin audio maestro",
        "dlg_no_master_body":      "No has seleccionado audio maestro.\n\n¿Sincronizar usando solamente el audio de las cámaras?\nSe usará el clip más largo como referencia y los demás se alinearán contra él.\n\nLos clips que no se solapen con el de referencia caerán a timestamp y quedarán en violeta.",
        "dlg_success_title":       "✅ Éxito",
        "dlg_error_title":         "❌ Error",

        # ── Sync log strings (mostly emitted by SyncWorker) ────────────
        "log_python":              "🔧  Python:   {path}",
        "log_ffmpeg":              "🔧  ffmpeg:   {path}",
        "log_ffprobe":             "🔧  ffprobe:  {path}",
        "log_librosa_ok":          "🔧  librosa:  OK",
        "log_librosa_missing":     "🔧  librosa:  ⚠️  AUSENTE",
        "log_libs_critical":       "❌ ERROR CRÍTICO — librosa/numpy/scipy NO disponibles",
        "log_python_current":      "    Python actual: {path}",
        "log_no_waveform_warn":    "    Sin esto, NO hay sincronización por waveform.",
        "err_libs_msg":            "❌ Audio libraries (librosa/numpy/scipy) no están instaladas\nen el Python que está corriendo este GUI:\n   {path}\n\nInstálalas con:\n   {path} -m pip install librosa numpy scipy",

        "log_preflight":           "\n🩺  Preflight — verificando ffmpeg en el primer master…",
        "log_preflight_deferred":  "\n🩺  Preflight diferido — master virtual se elige tras leer los clips.",
        "log_preflight_virtual":   "\n🩺  Preflight (master virtual) — verificando ffmpeg…",
        "log_ffmpeg_decoded":      "   ✓  ffmpeg decodificó {n} muestras de {name} en {t:.1f}s",
        "log_ffmpeg_decoded_v":    "   ✓  ffmpeg decodificó {n} muestras en {t:.1f}s",
        "log_ffmpeg_zero":         "   ❌  ffmpeg devolvió 0 muestras — algo falla con el binario o el archivo",
        "log_exception":           "   ❌  Excepción: {err}",
        "err_ffmpeg_preflight":    "❌ ffmpeg no pudo decodificar audio en preflight.\nBinario: {bin}\nVerifica que el archivo exista y que ffmpeg corra desde la terminal:\n   {bin} -i \"{path}\"",
        "err_ffmpeg_virtual":      "❌ ffmpeg no pudo decodificar el master virtual.\nBinario: {bin}\nArchivo: {path}\nPrueba desde terminal:\n   {bin} -i \"{path}\"",

        "log_loading_clips":       "📋  Obteniendo clips de cada cámara desde DaVinci...",
        "log_cam_loading":         "   📹  {cam}...",
        "log_cam_warning":         "   ⚠️  {err}",
        "log_cam_count":           "   ✓  {n} clip(s)  @ {fps:g} fps",
        "log_fps_mismatch":        "\n⚠️  Las timelines de origen tienen frame rates DIFERENTES: {fps_list}\n   Usaré {fps:g} fps (último procesado) para los cálculos y\n   forzaré ese fps en la timeline de salida.  Si tu proyecto\n   default es otro fps, puede haber drift.  Recomendación:\n   conforma todas las timelines al mismo fps antes de sincronizar.",
        "log_fps_consistent":      "   ✓  Todas las timelines a {fps:g} fps",

        "log_reading_metadata":    "\n📅  Leyendo creation_time de metadatos (ffprobe)...",
        "log_metadata_summary":    "   ✓  embedded={ok}  mtime_fallback={mt}  sin_tiempo={none}",

        "log_no_master_searching": "\n🎙  Sin audio maestro — buscando el clip de cámara más largo…",
        "log_virtual_master":      "   🎯  Master virtual = [{cam}] {name}  ({dur:.1f} min)",
        "log_virtual_master_info": "   ℹ️  Los demás clips de cámara se sincronizarán contra ESTE clip.  Los que no se solapen en el tiempo caerán a timestamp y quedarán violetas.",
        "err_no_virtual_master":   "❌ No hay master virtual usable.\nNecesito al menos un clip de cámara > 30 s para servir de referencia.  Selecciona un audio maestro manualmente o agrega clips más largos.",
        "err_no_master_selected":  "Selecciona al menos un audio master, o vuelve a abrir el sync con la opción de master virtual habilitada.",
        "log_master_too_short":    "⚠️  Descartando master demasiado corto: {name}  ({dur:.1f}s < {min:.0f}s)",
        "log_masters_filtered":    "   ✓  {kept} de {total} master(s) usables después de filtrar",
        "err_all_masters_short":   "❌ Todos los masters seleccionados son demasiado cortos (< {min:.0f}s).  No se puede sincronizar.\nPara correlación de waveform se necesitan masters de al menos 30-40 segundos.",

        "log_loading_masters":     "\n🎙  Cargando audio masters completos a 4 kHz…",
        "log_master_loading_one":  "   🎙  {name} …",
        "log_master_loaded":       "   ✓  {dur:.1f} min  ({n:,} samples)",
        "log_master_load_fail":    "   ⚠️  no se pudo cargar",
        "log_load_time":           "   ⏱  carga de masters: {t:.1f}s",
        "err_no_master_loaded":    "Ningún master se pudo cargar.\nVerifica que ffmpeg funcione: {bin}",
        "log_no_master_loaded":    "❌ Ningún master de audio se pudo cargar.",

        "log_correlation_start":   "\n🔍  Correlación sliding-window  (cluster window={win}s, min={min})…",
        "log_cam_no_clips":        "   ⚠️  {cam}: sin clips, se omite",
        "log_cam_processing":      "\n   📹  {cam}  ({n} clips)",
        "log_clip_not_found":      "      ⚠️  [{i}/{n}] No encontrado: {name}",
        "log_clip_processing":     "      🎞  [{i}/{n}] {name}",
        "log_clip_time":           "         ⏱  {t:.1f}s ({m} masters)",
        "log_clip_result":         "      {star} {name}  →  {pos:.2f} min  [{master}]  (conf={conf:.4f})",
        "log_corr_summary":        "\n   ⏱  Correlación: {n} análisis en {t:.1f}s (skip={s})",
        "log_corr_zero":           "❌ NINGUNA correlación de waveform se ejecutó — verifica masters cargados / ffmpeg.",
        "log_corr_suspicious":     "⚠️  Correlación sospechosamente rápida — puede que ffmpeg falle al extraer audio de los clips.",

        "log_clustering":          "\n⚓  Clustering derivaciones de zoom_start…",
        "log_cluster_ok":          "   🎯  [{cam}] {name}: zoom_start={t}  cluster={size}/{total}  spread={spread:.1f}s  max_conf={mc:.3f}",
        "log_cluster_no_peak":     "sin pico fuerte  max_conf={mc:.3f}<{thr}",
        "log_cluster_no_compact":  "sin cluster compacto",
        "log_cluster_few":         "pocas derivaciones  n={n}",
        "log_cluster_rejected":    "   ·   [{cam}] {name}: {reason}",

        "log_virtual_anchor":      "   🔗  [{cam}] master virtual anclado a creation_time = {t}",

        "log_best_master":         "   ✅  [{cam}] → master: {name}  (cluster={n})",
        "log_no_cluster":          "   ⚠️  [{cam}]: sin cluster en ningún master — se usará posición de waveform",
        "log_no_clusters_global":  "   ⚠️  Sin clusters detectados — se usará posición de waveform para todos los clips.",

        "log_global_ref":          "\n📐  Calculando referencia global por cámara…",
        "log_cam_ref":             "   📌  [{cam}] ref = {t}",
        "log_final_positions":     "\n📐  Calculando posiciones finales en el timeline…",
        "log_clip_placement":      "   🎞  {name}  {ts}  {wf}  {d} {so} → {off:.2f}m  frame={frame}  [{method}]",
        "log_shift_clips":         "\n   ↔  Desplazando {t:.2f}s (clips antes del inicio del master)",

        "log_overlap_check":       "\n🛡  Verificando orden y no-solape dentro de cada cámara…",
        "log_overlap_pushed":      "   ⚠️  [{cam}] {n} clip(s) empujados para evitar solapes  (total {f} frames = {s:.1f}s)",

        "log_building_timeline":   "\n🏗   Construyendo timeline '{name}' en DaVinci…",
        "log_master_placed":       "   🎙  {name}  @ {min:.1f} min (frame {frame})",
        "log_master_no_cluster":   "   🎙  {name}  → sin cluster, colocado al inicio",
        "log_master_relations":    "\n🔍  Analizando relación entre masters…",
        "log_masters_parallel":    "   ⚡  Detectados masters PARALELOS (solapan en el tiempo)",
        "log_masters_continuous":  "   ✅  Detectados masters CONTINUOS (no solapan)",
        "log_master_window":       "      {name}  ({s:.1f}–{e:.1f} min)",
        "log_n_master_tracks":     "   📌  {n} master(s) → {n} pista(s) de audio (una por master)",
        "log_virtual_master_track":"   📌  Master virtual = {name}  (no se añade como pista — vive en su cámara)",

        "err_create_timeline":     "❌ Error creando timeline:\n{err}",
        "log_warnings":            "   ⚠️  Advertencias:\n{lines}",

        "summary_title":           "✅ Timeline '{name}' creada en DaVinci",
        "summary_methods":         "Métodos usados: {totals}",
        "summary_methods_explain": "(wf = waveform es la verdad; ts = solo timestamp = sin waveform)",
        "summary_violet":          "🟣  {n} clip(s) coloreados VIOLETA (no sincronizados por waveform — revisar)",
        "summary_all_ts_warning":  "⚠️  TODOS los clips cayeron a TIMESTAMP — el waveform NO se usó.\nEsto suele indicar que ffmpeg no pudo decodificar audio o no hubo cluster con MIN_CLUSTER_SIZE clips.\nRevisa el log.",
        "summary_cam_line":        "• {cam}: {n} clip(s)  rango {rng}  [wf:{wf} wf+ts:{wfts} wf-cross:{wfc} ts:{ts}]",
        "summary_unknown_range":   "?",
        "log_sync_starting":       "▶  Sincronizando {n} timeline(s) con MASTER VIRTUAL (audio de cámara)...",
        "log_sync_starting_real":  "▶  Sincronizando {n} timeline(s) con {m} audio master(s)...",

        "err_unhandled":           "❌ Error: {err}\n{tb}",
    },
    "en": {
        # ── Window / header / top bar ──────────────────────────────────
        "window_title":            "Zync",
        "header_title":            "Zync",
        "connecting":              "Connecting to DaVinci...",
        "btn_refresh":             "⟳ Refresh",
        "btn_lang":                "🌐 ES",
        "btn_lang_tooltip":        "Switch to Spanish",
        "davinci_not_connected":   "⚠️  DaVinci not connected",
        "davinci_not_detected":    "⚠️  DaVinci not detected",
        "davinci_open_hint":       "  Open DaVinci with a project and press ⟳",
        "davinci_connect_log":     "⚠️  Could not connect to DaVinci.\nMake sure a project is open and External Scripting is enabled.\nPress ⟳ Refresh to retry.",

        # ── Left / right column titles ─────────────────────────────────
        "section_timelines":       "CAMERA TIMELINES",
        "section_audio_masters":   "MASTER AUDIO  (select one or more)",
        "tree_header_timeline":    "Timeline",
        "tree_header_file":        "File",
        "n_of_m_selected":         "{n}/{m} selected",
        "n_audios_in_project":     "{n} audio file(s) in project — check the masters",
        "no_audio_found":          "  ⚠️  No audio files found in: {path}",
        "no_project_path":         "  ⚠️  Could not detect the project path",
        "press_refresh_with_open": "  → Press ⟳ Refresh with DaVinci open",
        "use_browse_manual":       "Use '📂 Add file...' to select manually",
        "select_one_or_more":      "Select one or more master audio files",
        "n_masters_selected":      "✓  {n} master audio file(s) selected",
        "audios_searching":        "Searching for audio files...",
        "btn_browse":              "📂  Add file...",
        "browse_dialog_title":     "Select master audio file(s)",
        "browse_filter":           "Audio (*.wav *.mp3 *.aiff *.aif *.m4a *.flac);;All (*)",
        "manual_group":            "📁  Manual",
        "n_timelines_loaded":      "✅  {n} timelines loaded from '{name}'",

        # ── Bottom panel ───────────────────────────────────────────────
        "output_timeline":         "Output timeline:",
        "ready_to_sync":           "✅  Ready to sync",
        "btn_sync":                "▶   SYNC",
        "btn_clear":               "↺  Clear",
        "btn_exit":                "✕  Exit",
        "default_out_name":        "ZYNC_FINAL_SYNC",

        # ── Dialogs ────────────────────────────────────────────────────
        "dlg_no_selection_title":  "Nothing selected",
        "dlg_no_selection_body":   "Select at least one timeline.",
        "dlg_no_master_title":     "No master audio",
        "dlg_no_master_body":      "You did not select a master audio file.\n\nSync using only the camera audio?\nThe longest clip will be used as the reference and the rest will align against it.\n\nClips that don't overlap with the reference will fall back to timestamp and be marked violet.",
        "dlg_success_title":       "✅ Success",
        "dlg_error_title":         "❌ Error",

        # ── Sync log strings ───────────────────────────────────────────
        "log_python":              "🔧  Python:   {path}",
        "log_ffmpeg":              "🔧  ffmpeg:   {path}",
        "log_ffprobe":             "🔧  ffprobe:  {path}",
        "log_librosa_ok":          "🔧  librosa:  OK",
        "log_librosa_missing":     "🔧  librosa:  ⚠️  MISSING",
        "log_libs_critical":       "❌ CRITICAL ERROR — librosa/numpy/scipy NOT available",
        "log_python_current":      "    Current Python: {path}",
        "log_no_waveform_warn":    "    Without these, NO waveform sync will happen.",
        "err_libs_msg":            "❌ Audio libraries (librosa/numpy/scipy) are not installed\nin the Python running this GUI:\n   {path}\n\nInstall with:\n   {path} -m pip install librosa numpy scipy",

        "log_preflight":           "\n🩺  Preflight — checking ffmpeg on first master…",
        "log_preflight_deferred":  "\n🩺  Preflight deferred — virtual master will be picked after loading clips.",
        "log_preflight_virtual":   "\n🩺  Preflight (virtual master) — checking ffmpeg…",
        "log_ffmpeg_decoded":      "   ✓  ffmpeg decoded {n} samples from {name} in {t:.1f}s",
        "log_ffmpeg_decoded_v":    "   ✓  ffmpeg decoded {n} samples in {t:.1f}s",
        "log_ffmpeg_zero":         "   ❌  ffmpeg returned 0 samples — something is wrong with the binary or the file",
        "log_exception":           "   ❌  Exception: {err}",
        "err_ffmpeg_preflight":    "❌ ffmpeg could not decode audio in preflight.\nBinary: {bin}\nMake sure the file exists and ffmpeg runs from the terminal:\n   {bin} -i \"{path}\"",
        "err_ffmpeg_virtual":      "❌ ffmpeg could not decode the virtual master.\nBinary: {bin}\nFile: {path}\nTry from terminal:\n   {bin} -i \"{path}\"",

        "log_loading_clips":       "📋  Loading clips from each camera in DaVinci...",
        "log_cam_loading":         "   📹  {cam}...",
        "log_cam_warning":         "   ⚠️  {err}",
        "log_cam_count":           "   ✓  {n} clip(s)  @ {fps:g} fps",
        "log_fps_mismatch":        "\n⚠️  Source timelines have DIFFERENT frame rates: {fps_list}\n   Will use {fps:g} fps (last processed) for calculations and\n   force that fps on the output timeline.  If your project\n   default is a different fps there may be drift.  Recommendation:\n   conform all timelines to the same fps before syncing.",
        "log_fps_consistent":      "   ✓  All timelines at {fps:g} fps",

        "log_reading_metadata":    "\n📅  Reading creation_time from metadata (ffprobe)...",
        "log_metadata_summary":    "   ✓  embedded={ok}  mtime_fallback={mt}  no_time={none}",

        "log_no_master_searching": "\n🎙  No master audio — looking for the longest camera clip…",
        "log_virtual_master":      "   🎯  Virtual master = [{cam}] {name}  ({dur:.1f} min)",
        "log_virtual_master_info": "   ℹ️  Other camera clips will sync against THIS one.  Clips that don't overlap in time will fall back to timestamp and be marked violet.",
        "err_no_virtual_master":   "❌ No usable virtual master.\nI need at least one camera clip > 30 s to use as a reference.  Select a master audio file manually or add longer clips.",
        "err_no_master_selected":  "Select at least one master audio file, or reopen sync with the virtual master option enabled.",
        "log_master_too_short":    "⚠️  Discarding master that is too short: {name}  ({dur:.1f}s < {min:.0f}s)",
        "log_masters_filtered":    "   ✓  {kept} of {total} master(s) usable after filtering",
        "err_all_masters_short":   "❌ All selected masters are too short (< {min:.0f}s).  Cannot sync.\nWaveform correlation needs masters of at least 30-40 seconds.",

        "log_loading_masters":     "\n🎙  Loading full master audio at 4 kHz…",
        "log_master_loading_one":  "   🎙  {name} …",
        "log_master_loaded":       "   ✓  {dur:.1f} min  ({n:,} samples)",
        "log_master_load_fail":    "   ⚠️  could not load",
        "log_load_time":           "   ⏱  master loading: {t:.1f}s",
        "err_no_master_loaded":    "No master could be loaded.\nCheck that ffmpeg works: {bin}",
        "log_no_master_loaded":    "❌ No master audio could be loaded.",

        "log_correlation_start":   "\n🔍  Sliding-window correlation  (cluster window={win}s, min={min})…",
        "log_cam_no_clips":        "   ⚠️  {cam}: no clips, skipped",
        "log_cam_processing":      "\n   📹  {cam}  ({n} clips)",
        "log_clip_not_found":      "      ⚠️  [{i}/{n}] Not found: {name}",
        "log_clip_processing":     "      🎞  [{i}/{n}] {name}",
        "log_clip_time":           "         ⏱  {t:.1f}s ({m} masters)",
        "log_clip_result":         "      {star} {name}  →  {pos:.2f} min  [{master}]  (conf={conf:.4f})",
        "log_corr_summary":        "\n   ⏱  Correlation: {n} runs in {t:.1f}s (skip={s})",
        "log_corr_zero":           "❌ NO waveform correlation actually ran — check loaded masters / ffmpeg.",
        "log_corr_suspicious":     "⚠️  Correlation suspiciously fast — ffmpeg may be failing to extract clip audio.",

        "log_clustering":          "\n⚓  Clustering zoom_start derivations…",
        "log_cluster_ok":          "   🎯  [{cam}] {name}: zoom_start={t}  cluster={size}/{total}  spread={spread:.1f}s  max_conf={mc:.3f}",
        "log_cluster_no_peak":     "no strong peak  max_conf={mc:.3f}<{thr}",
        "log_cluster_no_compact":  "no compact cluster",
        "log_cluster_few":         "too few derivations  n={n}",
        "log_cluster_rejected":    "   ·   [{cam}] {name}: {reason}",

        "log_virtual_anchor":      "   🔗  [{cam}] virtual master anchored to creation_time = {t}",

        "log_best_master":         "   ✅  [{cam}] → master: {name}  (cluster={n})",
        "log_no_cluster":          "   ⚠️  [{cam}]: no cluster on any master — waveform position will be used",
        "log_no_clusters_global":  "   ⚠️  No clusters detected — waveform position will be used for all clips.",

        "log_global_ref":          "\n📐  Computing global reference per camera…",
        "log_cam_ref":             "   📌  [{cam}] ref = {t}",
        "log_final_positions":     "\n📐  Computing final timeline positions…",
        "log_clip_placement":      "   🎞  {name}  {ts}  {wf}  {d} {so} → {off:.2f}m  frame={frame}  [{method}]",
        "log_shift_clips":         "\n   ↔  Shifting {t:.2f}s (clips before master start)",

        "log_overlap_check":       "\n🛡  Checking order and no-overlap within each camera…",
        "log_overlap_pushed":      "   ⚠️  [{cam}] {n} clip(s) pushed to avoid overlap  (total {f} frames = {s:.1f}s)",

        "log_building_timeline":   "\n🏗   Building timeline '{name}' in DaVinci…",
        "log_master_placed":       "   🎙  {name}  @ {min:.1f} min (frame {frame})",
        "log_master_no_cluster":   "   🎙  {name}  → no cluster, placed at start",
        "log_master_relations":    "\n🔍  Analyzing relationship between masters…",
        "log_masters_parallel":    "   ⚡  PARALLEL masters detected (overlap in time)",
        "log_masters_continuous":  "   ✅  CONTINUOUS masters detected (no overlap)",
        "log_master_window":       "      {name}  ({s:.1f}–{e:.1f} min)",
        "log_n_master_tracks":     "   📌  {n} master(s) → {n} audio track(s) (one per master)",
        "log_virtual_master_track":"   📌  Virtual master = {name}  (not added as a track — lives on its camera)",

        "err_create_timeline":     "❌ Error creating timeline:\n{err}",
        "log_warnings":            "   ⚠️  Warnings:\n{lines}",

        "summary_title":           "✅ Timeline '{name}' created in DaVinci",
        "summary_methods":         "Methods used: {totals}",
        "summary_methods_explain": "(wf = waveform is truth; ts = timestamp only = no waveform)",
        "summary_violet":          "🟣  {n} clip(s) colored VIOLET (not waveform-synced — review)",
        "summary_all_ts_warning":  "⚠️  ALL clips fell to TIMESTAMP — waveform was NOT used.\nThis usually means ffmpeg couldn't decode audio or no cluster reached MIN_CLUSTER_SIZE.\nCheck the log.",
        "summary_cam_line":        "• {cam}: {n} clip(s)  range {rng}  [wf:{wf} wf+ts:{wfts} wf-cross:{wfc} ts:{ts}]",
        "summary_unknown_range":   "?",
        "log_sync_starting":       "▶  Syncing {n} timeline(s) with VIRTUAL MASTER (camera audio)...",
        "log_sync_starting_real":  "▶  Syncing {n} timeline(s) with {m} master audio file(s)...",

        "err_unhandled":           "❌ Error: {err}\n{tb}",
    },
}


def tr(key: str, **kwargs) -> str:
    """Translate a key to the current language, optionally with .format()."""
    s = TRANSLATIONS.get(CURRENT_LANG, TRANSLATIONS["es"]).get(key, key)
    if kwargs:
        try:
            return s.format(**kwargs)
        except (KeyError, IndexError, ValueError):
            return s
    return s


def set_lang(lang: str) -> None:
    """Switch the active language and persist to disk."""
    global CURRENT_LANG
    if lang not in TRANSLATIONS:
        return
    CURRENT_LANG = lang
    cfg = _load_config()
    cfg["lang"] = lang
    _save_config(cfg)


DARK_STYLE = """
QMainWindow, QWidget {
    background-color: #1a1a1a;
    color: #e0e0e0;
}
QTreeWidget, QListWidget {
    background-color: #252525;
    color: #e0e0e0;
    border: 1px solid #3a3a3a;
    border-radius: 4px;
    outline: none;
}
QTreeWidget::item, QListWidget::item {
    padding: 4px 6px;
    border-radius: 3px;
}
QTreeWidget::item:hover, QListWidget::item:hover {
    background-color: #2e2e2e;
}
QTreeWidget::item:selected, QListWidget::item:selected {
    background-color: #1e4d78;
    color: #ffffff;
}
QTreeWidget::branch {
    background-color: #252525;
}
QHeaderView::section {
    background-color: #2a2a2a;
    color: #888;
    border: none;
    padding: 4px 6px;
    font-size: 10px;
    text-transform: uppercase;
}
QPushButton {
    background-color: #2e2e2e;
    color: #e0e0e0;
    border: 1px solid #3a3a3a;
    border-radius: 5px;
    padding: 7px 12px;
    font-size: 11px;
}
QPushButton:hover {
    background-color: #383838;
    border-color: #555;
}
QPushButton:pressed {
    background-color: #222;
}
QPushButton:disabled {
    color: #555;
    border-color: #2a2a2a;
}
QPushButton#syncBtn {
    background-color: #1a6b2e;
    color: #ffffff;
    font-weight: bold;
    font-size: 13px;
    border: none;
    padding: 10px;
}
QPushButton#syncBtn:hover {
    background-color: #1f8035;
}
QPushButton#syncBtn:disabled {
    background-color: #1a3a22;
    color: #555;
}
QLineEdit {
    background-color: #252525;
    color: #e0e0e0;
    border: 1px solid #3a3a3a;
    border-radius: 4px;
    padding: 6px;
    font-size: 11px;
}
QLineEdit:focus {
    border-color: #1e6db5;
}
QLabel {
    color: #e0e0e0;
}
QLabel#sectionTitle {
    color: #aaa;
    font-size: 10px;
    letter-spacing: 1px;
}
QLabel#statusLabel {
    color: #888;
    font-size: 10px;
}
QLabel#logLabel {
    background-color: #1e1e1e;
    color: #aaffaa;
    border: 1px solid #2a2a2a;
    border-radius: 4px;
    padding: 8px;
    font-family: Menlo, Monaco, Courier, monospace;
    font-size: 10px;
}
QSplitter::handle {
    background-color: #2a2a2a;
    width: 1px;
}
QScrollBar:vertical {
    background: #1a1a1a;
    width: 6px;
    border-radius: 3px;
}
QScrollBar::handle:vertical {
    background: #444;
    border-radius: 3px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
"""


def _find_davinci_python():
    """Find a Python 3.10 interpreter that can load fusionscript.pyd.
    Priority: 1) bundled python_bridge next to the EXE, 2) system Python 3.10 from registry."""
    import platform
    if platform.system() != "Windows":
        return None

    # 1. Bundled python_bridge — shipped alongside Zync.exe in Zync_Windows.zip
    exe_dir = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
    bundled = os.path.join(exe_dir, "python_bridge", "python.exe")
    if os.path.exists(bundled):
        return bundled

    # 2. System Python 3.10 registered by DaVinci's own installer
    candidates = []
    try:
        import winreg
        for version in ["3.10", "3.6"]:
            key_path = rf"SOFTWARE\Python\PythonCore\{version}\InstallPath"
            for hive in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
                try:
                    with winreg.OpenKey(hive, key_path) as k:
                        install_dir = winreg.QueryValue(k, None)
                        exe = os.path.join(install_dir, "python.exe")
                        if os.path.exists(exe):
                            candidates.append(exe)
                except Exception:
                    pass
    except ImportError:
        pass

    # 3. Known DaVinci Python paths
    candidates += [
        r"C:\Program Files\Blackmagic Design\DaVinci Resolve\Python\python.exe",
        r"C:\Program Files\Blackmagic Design\DaVinci Resolve\Python3\python.exe",
        r"C:\Program Files\Blackmagic Design\DaVinci Resolve\Python310\python.exe",
    ]
    for c in candidates:
        if os.path.exists(c):
            return c
    return None



def _extract_bridge_script():
    """Find davinci_bridge.py — either from PyInstaller's temp extraction folder or next to the script."""
    # When frozen by PyInstaller, data files are extracted to sys._MEIPASS
    if getattr(sys, 'frozen', False):
        meipass = getattr(sys, '_MEIPASS', None)
        if meipass:
            candidate = os.path.join(meipass, "davinci_bridge.py")
            if os.path.exists(candidate):
                return candidate
    # Development mode: look next to this file
    candidate = os.path.join(os.path.dirname(os.path.abspath(__file__)), "davinci_bridge.py")
    if os.path.exists(candidate):
        return candidate
    return None


def _run_bridge(command="all"):
    """Run davinci_bridge.py as subprocess and return parsed JSON result"""
    import subprocess
    import tempfile
    import platform

    with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as temp_file:
        temp_path = temp_file.name

    frozen = getattr(sys, 'frozen', False)
    is_windows = platform.system() == "Windows"

    if frozen and is_windows:
        # On Windows compiled exe: must use DaVinci's Python to load fusionscript.pyd.
        # Re-calling sys.executable won't work because the bundled Python can't load DaVinci's DLL.
        davinci_python = _find_davinci_python()
        bridge_script = _extract_bridge_script()
        if davinci_python and bridge_script:
            cmd_args = [davinci_python, bridge_script, command, "--out_file", temp_path]
        else:
            # Last resort: try self with --bridge (may fail but gives an error message)
            cmd_args = [sys.executable, "--bridge", command, "--out_file", temp_path]
    elif frozen:
        # Mac/Linux frozen: re-execute self with --bridge flag
        cmd_args = [sys.executable, "--bridge", command, "--out_file", temp_path]
    else:
        bridge = Path(__file__).parent / "davinci_bridge.py"
        cmd_args = [sys.executable, str(bridge), command, "--out_file", temp_path]

    try:
        r = subprocess.run(
            cmd_args,
            capture_output=True, text=True, timeout=20
        )
        with open(temp_path, "r", encoding="utf-8") as f:
            output = f.read()
            if not output.strip():
                return {"success": False, "error": r.stderr.strip() or f"Bridge produced empty output. Python: {cmd_args[0]}"}
            return json.loads(output)
    except Exception as e:
        return {"success": False, "error": str(e)}
    finally:
        if os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass


def get_davinci_timelines():
    """Connect to DaVinci via bridge and return (project_name, timelines, media_root, clips, error)"""
    data = _run_bridge("all")

    if not data.get("success"):
        return None, None, None, [], data.get("error", "Unknown error")

    project_name = data.get("project_name")
    timelines    = [t["name"] for t in data.get("timelines", [])]
    media_root   = data.get("media_root")
    clips        = data.get("clips", [])

    return project_name, timelines, media_root, clips, None


def find_audio_files(project_root: str = None):
    """Search for audio files only within the project's media root"""
    audio_extensions = {'.wav', '.mp3', '.aiff', '.aif', '.m4a', '.flac', '.ogg'}
    found = []
    seen = set()

    if not project_root or not Path(project_root).exists():
        return found  # return empty — no project connected

    try:
        for f in Path(project_root).rglob("*"):
            if not f.is_file():
                continue
            if f.name.startswith("._"):  # skip macOS resource forks
                continue
            if f.suffix.lower() not in audio_extensions:
                continue
            if str(f) not in seen:
                seen.add(str(f))
                found.append({
                    "name": f.name,
                    "path": str(f),
                    "group": Path(project_root).name,
                    "folder": str(f.parent),
                })
    except PermissionError:
        pass

    return found


class SyncWorker(QThread):
    progress = pyqtSignal(str)
    finished = pyqtSignal(bool, str)

    def __init__(self, camera_timelines: List[str], audio_masters: List[str],
                 output_name: str, python_cmd: str,
                 use_virtual_master: bool = False,
                 lang: str = "es"):
        super().__init__()
        self.camera_timelines   = camera_timelines
        self.audio_masters      = list(audio_masters)
        self.output_name        = output_name
        self.python_cmd         = python_cmd
        self.bridge             = Path(__file__).parent / "davinci_bridge.py"
        self.use_virtual_master = use_virtual_master
        self.lang               = lang if lang in TRANSLATIONS else "es"
        # Set after Step 1 if a virtual master gets picked.  Path of a camera
        # clip used as the audio reference instead of an external recorder.
        self.virtual_master_path = None

    def t(self, key: str, **kwargs) -> str:
        """Translate using the worker's snapshot language (so it stays
        consistent even if the user toggles language mid-sync)."""
        s = TRANSLATIONS.get(self.lang, TRANSLATIONS["es"]).get(key, key)
        if kwargs:
            try:
                return s.format(**kwargs)
            except (KeyError, IndexError, ValueError):
                return s
        return s

    def bridge_call(self, *args):
        import subprocess
        import tempfile
        import os
        import platform

        with tempfile.NamedTemporaryFile(delete=False, suffix=".json") as temp_file:
            temp_path = temp_file.name

        frozen = getattr(sys, 'frozen', False)
        is_windows = platform.system() == "Windows"

        if frozen and is_windows:
            davinci_python = _find_davinci_python()
            bridge_script = _extract_bridge_script()
            if davinci_python and bridge_script:
                cmd_args = [davinci_python, bridge_script] + list(args) + ["--out_file", temp_path]
            else:
                cmd_args = [self.python_cmd, "--bridge"] + list(args) + ["--out_file", temp_path]
        elif frozen:
            cmd_args = [self.python_cmd, "--bridge"] + list(args) + ["--out_file", temp_path]
        else:
            cmd_args = [self.python_cmd, str(self.bridge)] + list(args) + ["--out_file", temp_path]

        try:
            r = subprocess.run(
                cmd_args,
                capture_output=True, text=True, timeout=300
            )
            with open(temp_path, "r", encoding="utf-8") as f:
                output = f.read()
                if not output.strip():
                    return {"success": False, "error": r.stderr.strip() or "No output from bridge file."}
                return json.loads(output)
        except json.JSONDecodeError as e:
            return {"success": False, "error": f"bridge JSON parse error: {e}\noutput: {output[:500]}"}
        except Exception as e:
            return {"success": False, "error": str(e)}
        finally:
            if os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except:
                    pass

    def run(self):
        try:
            from multi_camera_sync_mcp import (
                load_audio_full, load_audio_ffmpeg, find_clip_position_in_master,
                get_media_metadata, COARSE_SR,
                AUDIO_LIBS_AVAILABLE, FFMPEG_BIN, FFPROBE_BIN
            )
            from datetime import timedelta, datetime, timezone
            from collections import defaultdict
            import statistics
            import time as _time
            fps = 23.976
            self.progress.emit(self.t("log_python", path=sys.executable))
            self.progress.emit(self.t("log_ffmpeg", path=FFMPEG_BIN))
            self.progress.emit(self.t("log_ffprobe", path=FFPROBE_BIN))
            self.progress.emit(self.t("log_librosa_ok") if AUDIO_LIBS_AVAILABLE
                               else self.t("log_librosa_missing"))

            # ── HARD-FAIL if audio libs missing ───────────────────────────
            if not AUDIO_LIBS_AVAILABLE:
                self.progress.emit(self.t("log_libs_critical"))
                self.progress.emit(self.t("log_python_current", path=sys.executable))
                self.progress.emit(self.t("log_no_waveform_warn"))
                self.finished.emit(False, self.t("err_libs_msg", path=sys.executable))
                return

            # ── PREFLIGHT: verify ffmpeg can actually decode audio ────────
            if self.audio_masters:
                self.progress.emit(self.t("log_preflight"))
                preflight_ok = False
                try:
                    test_path = self.audio_masters[0]
                    t0 = _time.time()
                    test_wave = load_audio_ffmpeg(
                        test_path, start_sec=0.0, duration_sec=5.0, sr=COARSE_SR
                    )
                    if test_wave is not None and len(test_wave) > 0:
                        self.progress.emit(self.t("log_ffmpeg_decoded",
                            n=len(test_wave), name=Path(test_path).name,
                            t=_time.time()-t0))
                        preflight_ok = True
                    else:
                        self.progress.emit(self.t("log_ffmpeg_zero"))
                except Exception as e:
                    self.progress.emit(self.t("log_exception", err=str(e)))
                if not preflight_ok:
                    self.finished.emit(False, self.t("err_ffmpeg_preflight",
                        bin=FFMPEG_BIN, path=self.audio_masters[0]))
                    return
            elif self.use_virtual_master:
                self.progress.emit(self.t("log_preflight_deferred"))

            # Consensus-cluster parameters.
            # Instead of requiring a single high-confidence clip, we collect ALL
            # correlation-derived zoom_start values per (camera, master) and look
            # for a tight cluster.  True matches cluster within a few seconds;
            # noise is spread uniformly across the full master duration.
            CLUSTER_WINDOW_SEC    = 30.0  # derivations within this window = same cluster
            MIN_CLUSTER_SIZE      = 2     # minimum clips that must agree
            # ── Waveform-as-primary policy ──────────────────────────────────
            # WF_PRIMARY_CONF  : above this confidence waveform is used directly
            #                    regardless of how far it is from the timestamp.
            #                    (Camera clocks can drift; a strong wf peak IS ground truth.)
            # RECTIFY_CONF_MIN : medium confidence — use wf only if ts/wf agree
            #                    within RECTIFY_TOLERANCE_SEC.
            # RECTIFY_TOLERANCE_SEC: tolerance for medium-confidence rectification.
            WF_PRIMARY_CONF      = 0.08  # conf ≥ this → always use waveform
            RECTIFY_CONF_MIN     = 0.04  # conf ≥ this (< WF_PRIMARY) → use wf if within tolerance
            RECTIFY_TOLERANCE_SEC = 30.0 # tolerance for medium-conf wf agreement with ts
            # Hard sanity ceiling for HIGH-conf waveform: even if conf is ≥
            # WF_PRIMARY_CONF, if wf disagrees with ts by MORE than this, the
            # match is almost certainly a false peak (a long master can have
            # high cross-correlation against a clip's audio at a totally
            # wrong position when there's a lot of music/repetition).  In
            # that case we trust ts (which is consistent within a camera as
            # long as that camera's cluster is good).  This catches the
            # "SONY clip false-peak'd against a 3.5h master" failure mode.
            WF_SANITY_CEILING_SEC = 600.0  # 10 minutes

            # ── Step 1: clips from DaVinci ────────────────────────────────
            self.progress.emit(self.t("log_loading_clips"))
            timeline_clips:    Dict[str, List]  = {}
            timeline_fps_per_cam: Dict[str, float] = {}
            for cam in self.camera_timelines:
                self.progress.emit(self.t("log_cam_loading", cam=cam))
                data = self.bridge_call("timeline_clips", cam)
                if not data.get("success"):
                    self.progress.emit(self.t("log_cam_warning", err=data.get("error")))
                    timeline_clips[cam] = []
                else:
                    clips = [c for c in data.get("clips", []) if c.get("file_path")]
                    timeline_clips[cam] = clips
                    cam_fps = float(data.get("fps", 23.976))
                    timeline_fps_per_cam[cam] = cam_fps
                    fps = cam_fps   # last-wins; cross-camera consistency checked below
                    self.progress.emit(self.t("log_cam_count", n=len(clips), fps=cam_fps))

            # ── fps sanity check across source timelines ──────────────────
            # All record_frame math + the new timeline's frame rate must use
            # the SAME fps.  If source timelines disagree, picking the wrong
            # one here causes a proportional drift (e.g. 24 vs 23.976 = 0.1%
            # ≈ 1.8 s over a 30-min event; 24 vs 25 = 4 % ≈ 72 s).
            unique_fps = sorted(set(round(v, 3) for v in timeline_fps_per_cam.values()))
            if len(unique_fps) > 1:
                self.progress.emit(self.t("log_fps_mismatch",
                    fps_list=unique_fps, fps=fps))
            elif unique_fps:
                self.progress.emit(self.t("log_fps_consistent", fps=unique_fps[0]))

            # ── Step 1b: creation_time from each clip's media file ────────
            self.progress.emit(self.t("log_reading_metadata"))
            ct_ok = ct_mtime = ct_none = 0
            for cam in self.camera_timelines:
                for clip in timeline_clips.get(cam, []):
                    fp = clip.get("file_path", "")
                    if fp and Path(fp).exists():
                        meta = get_media_metadata(fp)
                        
                        # --- NEW: VFR & RAW handling ---
                        if meta.get("is_vfr", False):
                            self.progress.emit(f"   ⚠️  VFR Detectado: {Path(fp).name}. Convirtiendo a CFR...")
                            import subprocess
                            out_path = Path(fp).parent / f"{Path(fp).stem}_CFR.mov"
                            if not out_path.exists():
                                try:
                                    cmd = [
                                        FFMPEG_BIN, "-i", fp, "-r", str(fps), "-fps_mode", "cfr",
                                        "-c:v", "prores_ks", "-profile:v", "1", "-c:a", "pcm_s16le",
                                        "-y", str(out_path)
                                    ]
                                    subprocess.run(cmd, check=True, capture_output=True)
                                    self.progress.emit(f"   ✅  Transcodificado exitosamente a CFR.")
                                    # Update clip so we use and import the new file
                                    clip["file_path"] = str(out_path)
                                    fp = str(out_path)
                                    meta = get_media_metadata(fp) # Refresh metadata
                                except Exception as e:
                                    self.progress.emit(f"   ❌  Error transcodificando: {e}")
                            else:
                                self.progress.emit(f"   ✅  Archivo CFR ya existe. Usando versión transcodificada.")
                                clip["file_path"] = str(out_path)
                                fp = str(out_path)
                                meta = get_media_metadata(fp) # Refresh metadata
                                
                        if meta.get("is_raw", False):
                            self.progress.emit(f"   ⚠️  Formato RAW detectado: {Path(fp).name}. Intentando extraer audio directamente...")
                        # --------------------------------
                        
                        ct = meta.get("creation_time")
                        if ct is not None:
                            clip["creation_time"] = ct
                            ct_ok += 1
                        else:
                            # fallback: use filesystem mtime (usually close to recording time)
                            clip["creation_time"] = meta.get("file_mtime")
                            ct_mtime += 1
                    else:
                        clip["creation_time"] = None
                        ct_none += 1
            self.progress.emit(self.t("log_metadata_summary",
                ok=ct_ok, mt=ct_mtime, none=ct_none))

            # ── Step 1c: pick a VIRTUAL MASTER if no audio recorder was given ──
            # When the user didn't select any external audio file, fall back to
            # using the camera clip with the LONGEST duration as the reference.
            # Long clips have more distinctive audio events, so cross-correlation
            # against them is much more reliable than against a 5-second clip.
            # The chosen clip stays where it would normally land on its camera's
            # video track — we just *also* use its audio as the master signal.
            if not self.audio_masters and self.use_virtual_master:
                self.progress.emit(self.t("log_no_master_searching"))
                longest_path = None
                longest_dur  = 0.0
                longest_cam  = None
                for cam in self.camera_timelines:
                    for clip in timeline_clips.get(cam, []):
                        fp = clip.get("file_path", "")
                        if not fp or not Path(fp).exists():
                            continue
                        meta = get_media_metadata(fp)
                        dur  = meta.get("duration", 0.0) or 0.0
                        if dur > longest_dur:
                            longest_dur  = dur
                            longest_path = fp
                            longest_cam  = cam
                if longest_path is None or longest_dur < 30.0:
                    self.finished.emit(False, self.t("err_no_virtual_master"))
                    return
                self.audio_masters       = [longest_path]
                self.virtual_master_path = longest_path
                self.progress.emit(self.t("log_virtual_master",
                    cam=longest_cam, name=Path(longest_path).name,
                    dur=longest_dur/60))
                self.progress.emit(self.t("log_virtual_master_info"))

                # Deferred preflight against the chosen virtual master
                self.progress.emit(self.t("log_preflight_virtual"))
                t0 = _time.time()
                try:
                    test_wave = load_audio_ffmpeg(
                        longest_path, start_sec=0.0, duration_sec=5.0,
                        sr=COARSE_SR
                    )
                except Exception as e:
                    test_wave = None
                    self.progress.emit(self.t("log_exception", err=str(e)))
                if test_wave is None or len(test_wave) == 0:
                    self.finished.emit(False, self.t("err_ffmpeg_virtual",
                        bin=FFMPEG_BIN, path=longest_path))
                    return
                self.progress.emit(self.t("log_ffmpeg_decoded_v",
                    n=len(test_wave), t=_time.time()-t0))
            elif not self.audio_masters:
                # No master given AND virtual-master mode not enabled
                self.finished.emit(False, self.t("err_no_master_selected"))
                return

            # ── Step 1d: filter out unusable masters ──────────────────────
            from multi_camera_sync_mcp import CLIP_SKIP_SECS, CLIP_SAMPLE_SECS
            MIN_USABLE_MASTER_SEC = float(CLIP_SKIP_SECS + CLIP_SAMPLE_SECS + 5.0)
            usable_masters = []
            for ap in self.audio_masters:
                meta = get_media_metadata(ap)
                dur  = meta.get("duration", 0.0) or 0.0
                if dur < MIN_USABLE_MASTER_SEC:
                    self.progress.emit(self.t("log_master_too_short",
                        name=Path(ap).name, dur=dur, min=MIN_USABLE_MASTER_SEC))
                else:
                    usable_masters.append(ap)
            if not usable_masters:
                self.finished.emit(False, self.t("err_all_masters_short",
                    min=MIN_USABLE_MASTER_SEC))
                return
            if len(usable_masters) < len(self.audio_masters):
                self.progress.emit(self.t("log_masters_filtered",
                    kept=len(usable_masters), total=len(self.audio_masters)))
            self.audio_masters = usable_masters

            # ── Step 2: load every master once at 4 kHz ──────────────────
            self.progress.emit(self.t("log_loading_masters"))
            master_waves: Dict[str, object] = {}   # path → np.ndarray | None
            t_load = _time.time()
            for ap in self.audio_masters:
                name = Path(ap).name
                self.progress.emit(self.t("log_master_loading_one", name=name))
                wave = load_audio_full(ap, sr=COARSE_SR)
                master_waves[ap] = wave
                if wave is not None:
                    dur_min = len(wave) / COARSE_SR / 60
                    self.progress.emit(self.t("log_master_loaded",
                        dur=dur_min, n=len(wave)))
                else:
                    self.progress.emit(self.t("log_master_load_fail"))
            self.progress.emit(self.t("log_load_time", t=_time.time()-t_load))

            loaded = sum(1 for w in master_waves.values() if w is not None)
            if loaded == 0:
                self.progress.emit(self.t("log_no_master_loaded"))
                self.finished.emit(False, self.t("err_no_master_loaded", bin=FFMPEG_BIN))
                return

            # ── Step 3: sliding-window correlation — every clip × every master ─
            self.progress.emit(self.t("log_correlation_start",
                win=CLUSTER_WINDOW_SEC, min=MIN_CLUSTER_SIZE))
            t_corr      = _time.time()
            corr_done   = 0  # how many real correlations were performed
            corr_skip   = 0  # how many were skipped (no master wave)
            # Each entry: {cam, clip, best_pos, best_conf, best_master, all_results}
            search_results: List[Dict] = []

            total_clips = sum(len(timeline_clips.get(c, [])) for c in self.camera_timelines)
            clip_idx    = 0
            for cam in self.camera_timelines:
                clips = timeline_clips.get(cam, [])
                if not clips:
                    self.progress.emit(self.t("log_cam_no_clips", cam=cam))
                    continue
                self.progress.emit(self.t("log_cam_processing", cam=cam, n=len(clips)))

                for clip in clips:
                    clip_idx += 1
                    fp = clip.get("file_path", "")
                    clip_name = Path(fp).name if fp else "?"

                    if not fp or not Path(fp).exists():
                        self.progress.emit(self.t("log_clip_not_found",
                            i=clip_idx, n=total_clips, name=clip_name))
                        search_results.append({
                            "cam": cam, "clip": clip,
                            "best_pos": 0.0, "best_conf": 0.0,
                            "best_master": self.audio_masters[0],
                            "all_results": {},
                        })
                        continue

                    t_clip = _time.time()
                    self.progress.emit(self.t("log_clip_processing",
                        i=clip_idx, n=total_clips, name=clip_name))

                    all_results: Dict[str, tuple] = {}   # master_path → (pos_sec, conf)
                    best_pos    = 0.0
                    best_conf   = -1.0
                    best_master = self.audio_masters[0]

                    for ap, mwave in master_waves.items():
                        if mwave is None:
                            all_results[ap] = (0.0, 0.0)
                            corr_skip += 1
                            continue
                        pos, conf = find_clip_position_in_master(
                            clip_path=fp,
                            master_wave=mwave,
                            master_path=ap,
                            master_sr=COARSE_SR,
                            log_fn=lambda m: self.progress.emit(m),
                        )
                        all_results[ap] = (pos, conf)
                        corr_done += 1
                        if conf > best_conf:
                            best_conf   = conf
                            best_pos    = pos
                            best_master = ap

                    self.progress.emit(self.t("log_clip_time",
                        t=_time.time()-t_clip,
                        m=len([w for w in master_waves.values() if w is not None])))

                    star = "⭐" if best_conf >= 0.08 else "  "
                    self.progress.emit(self.t("log_clip_result",
                        star=star, name=clip_name, pos=best_pos/60,
                        master=Path(best_master).name, conf=best_conf))
                    search_results.append({
                        "cam": cam, "clip": clip,
                        "best_pos": best_pos, "best_conf": best_conf,
                        "best_master": best_master,
                        "all_results": all_results,
                    })

            corr_elapsed = _time.time() - t_corr
            self.progress.emit(self.t("log_corr_summary",
                n=corr_done, t=corr_elapsed, s=corr_skip))
            if corr_done == 0:
                self.progress.emit(self.t("log_corr_zero"))
            elif corr_elapsed < 2.0 and corr_done > 5:
                self.progress.emit(self.t("log_corr_suspicious"))

            # ── Step 4: consensus-cluster zoom_start derivation ──────────────
            #
            # For every clip × every master we already have a correlation position.
            # Compute zoom_start = clip.creation_time − pos_in_master for EACH
            # (clip, master) pair, then look for a tight cluster per (camera, master).
            #
            # Why this works even with low per-clip confidence (music events):
            #   • True matches: clips that actually overlap with the master all derive
            #     nearly the same zoom_start → tight cluster
            #   • Noise: false-peak matches land randomly across the master duration
            #     → spread uniformly, almost never cluster tightly
            #
            # Each camera keeps its own reference frame, so we never mix clock
            # systems from different manufacturers (CANON UTC vs SONY localtime).
            self.progress.emit(self.t("log_clustering"))

            # Minimum confidence that a cluster's STRONGEST member must reach
            # for the cluster to be considered real.  Without this gate, false
            # peaks from non-overlapping clips can occasionally cluster within
            # the time window (e.g. 3 random clips happening to land within
            # 30 s of each other) and produce a phantom zoom_start.  A real
            # cluster — clips actually inside the master's recording window —
            # will always contain at least one match with conf ≥ this threshold.
            CLUSTER_MIN_MAX_CONF = 0.08   # = WF_PRIMARY_CONF

            def find_cluster(derivations, window_sec, min_size, min_max_conf):
                """
                derivations: list of (datetime, confidence) tuples.
                Returns (median_datetime, cluster_size, max_conf).
                Rejects clusters where no member reaches min_max_conf — those
                are almost always false-peak artefacts even if they cluster
                tightly by chance.
                """
                if len(derivations) < min_size:
                    return None, 0, 0.0
                # Sort by timestamp
                ordered = sorted(derivations, key=lambda d: d[0].timestamp())
                epochs  = [d[0].timestamp() for d in ordered]
                confs   = [d[1] for d in ordered]
                best_median, best_count, best_max_conf = None, 0, 0.0
                for t in epochs:
                    members = [(epochs[i], confs[i]) for i in range(len(epochs))
                               if abs(epochs[i] - t) <= window_sec]
                    n = len(members)
                    cmax = max(c for _, c in members)
                    # Prefer larger clusters; tie-break by max confidence
                    if n > best_count or (n == best_count and cmax > best_max_conf):
                        best_count    = n
                        best_max_conf = cmax
                        best_median   = statistics.median(e for e, _ in members)
                if best_count < min_size or best_max_conf < min_max_conf:
                    return None, 0, 0.0
                return (datetime.fromtimestamp(best_median, tz=timezone.utc),
                        best_count, best_max_conf)

            # Collect (datetime, conf) derivations per (camera, master)
            zoom_start_derivations: Dict[tuple, List] = defaultdict(list)

            for r in search_results:
                clip = r["clip"]
                ct   = clip.get("creation_time")
                if ct is None:
                    continue
                for master_path, (pos_sec, conf) in r["all_results"].items():
                    if pos_sec <= 0:
                        continue
                    derived_start = ct - timedelta(seconds=pos_sec)
                    zoom_start_derivations[(r["cam"], master_path)].append(
                        (derived_start, conf)
                    )

            # Find consensus zoom_start for each (camera, master) pair
            zoom_start_times: Dict[tuple, datetime] = {}
            cluster_quality:  Dict[tuple, int]      = {}   # cluster_size

            for (cam_name, master), derivations in zoom_start_derivations.items():
                consensus_dt, cluster_size, cmax = find_cluster(
                    derivations, CLUSTER_WINDOW_SEC, MIN_CLUSTER_SIZE,
                    CLUSTER_MIN_MAX_CONF
                )
                if consensus_dt is not None:
                    zoom_start_times[(cam_name, master)] = consensus_dt
                    cluster_quality[(cam_name, master)]  = cluster_size
                    epochs   = sorted(d[0].timestamp() for d in derivations)
                    ctr      = consensus_dt.timestamp()
                    in_clust = [x for x in epochs if abs(x - ctr) <= CLUSTER_WINDOW_SEC]
                    spread   = max(in_clust) - min(in_clust) if len(in_clust) > 1 else 0.0
                    self.progress.emit(self.t("log_cluster_ok",
                        cam=cam_name, name=Path(master).name,
                        t=consensus_dt.strftime('%H:%M:%S'),
                        size=cluster_size, total=len(derivations),
                        spread=spread, mc=cmax))
                else:
                    if len(derivations) >= MIN_CLUSTER_SIZE:
                        max_conf_seen = max((c for _, c in derivations), default=0.0)
                        reason = (self.t("log_cluster_no_peak",
                                          mc=max_conf_seen, thr=CLUSTER_MIN_MAX_CONF)
                                  if max_conf_seen < CLUSTER_MIN_MAX_CONF else
                                  self.t("log_cluster_no_compact"))
                    else:
                        reason = self.t("log_cluster_few", n=len(derivations))
                    self.progress.emit(self.t("log_cluster_rejected",
                        cam=cam_name, name=Path(master).name, reason=reason))

            # ── Virtual-master anchor ────────────────────────────────────
            # The virtual master correlated against ITSELF gives a single
            # cluster member — not enough for MIN_CLUSTER_SIZE=2.  But we
            # know exactly when it started recording (its creation_time),
            # so we can directly anchor its owning camera here.
            if self.virtual_master_path is not None:
                for cam_name in self.camera_timelines:
                    for clip in timeline_clips.get(cam_name, []):
                        if clip.get("file_path") == self.virtual_master_path:
                            ct = clip.get("creation_time")
                            if ct is not None:
                                key = (cam_name, self.virtual_master_path)
                                if key not in zoom_start_times:
                                    zoom_start_times[key] = ct
                                    cluster_quality[key] = 100  # high priority
                                    self.progress.emit(self.t("log_virtual_anchor",
                                        cam=cam_name, t=ct.strftime('%H:%M:%S')))
                            break

            # For each camera, pick the master with the STRONGEST cluster
            # (most clips agreeing → most likely the correct ZOOM file for that camera)
            best_master_per_cam: Dict[str, str] = {}
            for cam_name in self.camera_timelines:
                candidates = {
                    master: cluster_quality[(cam_name, master)]
                    for master in self.audio_masters
                    if (cam_name, master) in cluster_quality
                }
                if candidates:
                    best = max(candidates, key=candidates.get)
                    best_master_per_cam[cam_name] = best
                    self.progress.emit(self.t("log_best_master",
                        cam=cam_name, name=Path(best).name, n=candidates[best]))
                else:
                    self.progress.emit(self.t("log_no_cluster", cam=cam_name))

            if not zoom_start_times:
                self.progress.emit(self.t("log_no_clusters_global"))

            # ── Step 5: compute record_frame for every clip ───────────────
            #
            # KEY INSIGHT for consecutive ZOOM files (e.g. ZOOM0012 → ZOOM0013):
            # If we derived zoom_start separately for each master, clips in ZOOM0013
            # would be positioned relative to ZOOM0013's start, NOT the global
            # timeline start.  This places them *on top* of the ZOOM0012 clips.
            #
            # Fix: for each camera, use the EARLIEST derived zoom_start as the
            # single global reference.  Then ALL clips from that camera use:
            #   offset_sec = clip.creation_time − reference_time
            # Clips in ZOOM0013 automatically land ~34 min later than ZOOM0012 clips.
            self.progress.emit(self.t("log_global_ref"))

            # Per-camera global reference = earliest zoom_start found for that camera
            cam_reference_time: Dict[str, object] = {}
            for cam_name in self.camera_timelines:
                earliest = None
                for master in self.audio_masters:
                    key = (cam_name, master)
                    if key in zoom_start_times:
                        zst = zoom_start_times[key]
                        if earliest is None or zst < earliest:
                            earliest = zst
                if earliest is not None:
                    cam_reference_time[cam_name] = earliest
                    self.progress.emit(self.t("log_cam_ref",
                        cam=cam_name, t=earliest.strftime('%H:%M:%S')))

            self.progress.emit(self.t("log_final_positions"))

            cam_clip_map: Dict[str, List] = {}
            min_record_frame = float("inf")

            for r in search_results:
                cam_name    = r["cam"]
                clip        = r["clip"]
                best_pos    = r["best_pos"]
                conf        = r["best_conf"]
                best_master = r["best_master"]
                ct          = clip.get("creation_time")
                clip_name   = Path(clip.get("file_path", "")).name

                if ct is not None and cam_name in cam_reference_time:
                    ref_time  = cam_reference_time[cam_name]
                    ts_offset = (ct - ref_time).total_seconds()

                    # ── Waveform-as-primary (per-clip master selection) ──────
                    # Use THIS clip's own best_master (highest correlation for
                    # THIS specific clip), NOT the camera-level forced master.
                    # This ensures e.g. IPHONE clips that fall in ZOOM0013 use
                    # ZOOM0013 positions rather than a false peak in ZOOM0012.
                    chosen_master    = best_master
                    wf_pos_in_master, wf_conf = r["all_results"].get(
                        chosen_master, (best_pos, best_conf)
                    )

                    # Find zoom_start: try (cam, master) first, then cross-camera
                    # for the same master if this camera has no cluster there.
                    zoom_key = (cam_name, chosen_master)
                    ref_cam  = cam_name

                    if zoom_key not in zoom_start_times:
                        # Cross-camera fallback: another camera that DID cluster
                        # with this master can anchor the global position.
                        # ts_offset and wf_global are both in real-world seconds
                        # relative to the common ZOOM recorder, so comparing them
                        # across cameras is valid (clock skew cancels in the delta).
                        for any_cam in self.camera_timelines:
                            alt_key = (any_cam, chosen_master)
                            if alt_key in zoom_start_times and any_cam in cam_reference_time:
                                zoom_key = alt_key
                                ref_cam  = any_cam
                                break

                    if zoom_key in zoom_start_times:
                        anchor_ref        = cam_reference_time[ref_cam]
                        zoom_start_offset = (zoom_start_times[zoom_key] - anchor_ref).total_seconds()
                        wf_global         = zoom_start_offset + wf_pos_in_master
                        discrepancy       = abs(ts_offset - wf_global)
                        cross             = (ref_cam != cam_name)

                        if wf_conf >= WF_PRIMARY_CONF and discrepancy <= WF_SANITY_CEILING_SEC:
                            # High confidence AND wf within sanity ceiling of ts.
                            # Real camera clock drift is at most a few minutes;
                            # if wf says "this clip is 2 hours away from where
                            # ts says it should be", it's a false peak.
                            offset_sec = wf_global
                            method     = (f"wf-cross(c={wf_conf:.3f})" if cross
                                          else f"wf(c={wf_conf:.3f})")
                        elif wf_conf >= WF_PRIMARY_CONF:
                            # High conf BUT wf disagrees with ts by more than
                            # 10 minutes — almost certainly a false peak in a
                            # long master.  Fall back to timestamp.
                            offset_sec = ts_offset
                            method     = (f"ts(wf_falso_pico Δ={discrepancy/60:.1f}min,c={wf_conf:.3f})")
                        elif wf_conf >= RECTIFY_CONF_MIN and discrepancy <= RECTIFY_TOLERANCE_SEC:
                            # Medium confidence and ts/wf roughly agree — use wf.
                            offset_sec = wf_global
                            method     = (f"wf-cross+ts(Δ={discrepancy:.1f}s,c={wf_conf:.3f})"
                                          if cross else
                                          f"wf+ts(Δ={discrepancy:.1f}s,c={wf_conf:.3f})")
                        else:
                            # Low confidence or large discrepancy — trust timestamp.
                            offset_sec = ts_offset
                            method     = (f"ts(wf_rechazado Δ={discrepancy:.1f}s)"
                                          if wf_conf >= RECTIFY_CONF_MIN else "ts")
                    else:
                        # No zoom_start for this master in any camera — ts only.
                        offset_sec  = ts_offset
                        wf_global   = None
                        discrepancy = None
                        method      = "ts"
                else:
                    # No creation_time or no cluster for this camera.
                    # Use waveform position anchored to ANY camera's zoom_start
                    # for the same master, so the clip lands at the right spot
                    # in the global timeline rather than at raw pos=0.
                    anchor_cam = None
                    for any_cam, rtime in cam_reference_time.items():
                        if (any_cam, best_master) in zoom_start_times:
                            anchor_cam = any_cam
                            break
                    if anchor_cam is not None and best_pos > 0:
                        anchor_ref    = cam_reference_time[anchor_cam]
                        master_offset = (
                            zoom_start_times[(anchor_cam, best_master)] - anchor_ref
                        ).total_seconds()
                        offset_sec = master_offset + best_pos
                        method     = f"wf-cross(c={best_conf:.3f})"
                    else:
                        offset_sec = best_pos
                        method     = f"wf(c={best_conf:.3f})"
                    ts_offset   = None
                    wf_global   = offset_sec
                    discrepancy = None

                # ── source_start (LeftOffset) compensation ────────────────
                # offset_sec is "where the SOURCE FRAME 0 should sit in the
                # master timeline".  But DaVinci places the clip starting at
                # its trimmed in-point (source_start frames into the source),
                # so the clip's first VISIBLE frame is source_start frames
                # later than source frame 0.  We must shift record_frame
                # forward by the same amount, otherwise the trimmed-off
                # head appears as if it were the start of the clip and the
                # whole clip lands `source_start / fps` seconds too early.
                #
                # This typically affects iPhone footage that was trimmed in
                # the source IPHONE timeline (lens warmup, focus-hunting
                # frames, etc.).  Camera clips that were used untrimmed
                # have source_start=0, so the addition is a no-op.
                source_start_frames = int(clip.get("source_start", 0) or 0)
                record_frame = int(offset_sec * fps) + source_start_frames
                if record_frame < min_record_frame:
                    min_record_frame = record_frame

                # Detailed per-clip log — shows ts vs wf so you can spot
                # systematic drift between camera clock and waveform truth.
                ts_str = f"ts={ts_offset/60:.2f}m" if ts_offset is not None else "ts=N/A"
                wf_str = f"wf={wf_global/60:.2f}m" if wf_global is not None else "wf=N/A"
                d_str  = f"Δ={discrepancy:.1f}s" if discrepancy is not None else ""
                so_str = f"so={source_start_frames}f" if source_start_frames else ""
                self.progress.emit(self.t("log_clip_placement",
                    name=clip_name, ts=ts_str, wf=wf_str, d=d_str, so=so_str,
                    off=offset_sec/60, frame=record_frame, method=method))

                cam_clip_map.setdefault(cam_name, []).append({
                    "file_path":         clip.get("file_path", ""),
                    "record_frame":      record_frame,
                    "source_start":      clip.get("source_start", 0),
                    "duration_frames":   clip.get("duration_frames", 100),
                    "offset_sec":        offset_sec,
                    "confidence":        conf,
                    "method":            method,
                    # Original source-timeline position — used below to enforce
                    # within-camera ordering (a single camera can't record two
                    # clips at the same time, so source order = canonical order).
                    "_orig_tl_start":    clip.get("timeline_start", 0),
                })

            # ── Step 5b: enforce no-overlap within each camera ─────────────
            # A single physical camera can only record one clip at a time, so
            # within a single camera:
            #   1. Clips MUST be in their source-timeline order.
            #   2. No two clips may overlap.
            # When sync produces a violation (e.g. a ts-only clip with wrong
            # camera-clock metadata, or a low-confidence wf hitting a false
            # peak), we push the conflicting clip forward to start right
            # after the previous clip ends.  We never pull clips backward —
            # that could cascade into earlier overlaps.
            #
            # Higher-confidence placements anchor the timeline; lower-conf
            # ones bend around them.  We walk in source order.
            self.progress.emit(self.t("log_overlap_check"))
            for cam_name in self.camera_timelines:
                placed = cam_clip_map.get(cam_name, [])
                if not placed:
                    continue
                # Sort by ORIGINAL source-timeline position (canonical order)
                placed.sort(key=lambda c: c.get("_orig_tl_start", 0))
                pushed       = 0
                pushed_total = 0
                prev_end     = -float("inf")
                for c in placed:
                    rf = c["record_frame"]
                    if rf < prev_end:
                        # Overlap: push forward to start right after previous
                        shift               = prev_end - rf
                        c["record_frame"]   = prev_end
                        c["method"]         = c.get("method", "") + f" [push +{shift}f]"
                        pushed             += 1
                        pushed_total       += shift
                    prev_end = c["record_frame"] + c.get("duration_frames", 0)
                if pushed:
                    self.progress.emit(self.t("log_overlap_pushed",
                        cam=cam_name, n=pushed, f=pushed_total,
                        s=pushed_total/fps))
                # Recompute min_record_frame in case pushing moved earliest
                for c in placed:
                    if c["record_frame"] < min_record_frame:
                        min_record_frame = c["record_frame"]
                # Drop the helper key — it's not needed downstream
                for c in placed:
                    c.pop("_orig_tl_start", None)
                cam_clip_map[cam_name] = placed

            # Shift everything so the earliest clip lands at frame 0.
            # ZOOM masters get the same shift (computed in Step 6).
            timeline_shift_frames = 0
            if min_record_frame != float("inf") and min_record_frame < 0:
                timeline_shift_frames = -min_record_frame
                self.progress.emit(self.t("log_shift_clips",
                    t=timeline_shift_frames / fps))
                for cam_clips in cam_clip_map.values():
                    for c in cam_clips:
                        c["record_frame"] = max(0, c["record_frame"] + timeline_shift_frames)

            # ── Step 6: build timeline spec ───────────────────────────────
            self.progress.emit(self.t("log_building_timeline", name=self.output_name))

            cam_track_specs = []
            for cam_idx, cam in enumerate(self.camera_timelines):
                if cam in cam_clip_map:
                    cam_track_specs.append({
                        "camera_name": cam,
                        "track_index": cam_idx + 1,
                        "clips":       cam_clip_map[cam],
                    })

            # Place each ZOOM master at the correct timeline position.
            #
            # For each master, find the camera with the strongest cluster and use
            # its reference time to compute:
            #   zoom_offset = zoom_start_for_this_master − cam_reference_time
            # Then: record_frame = zoom_offset * fps + timeline_shift_frames
            #
            # Consecutive ZOOMs (e.g. 0012 → 0013):
            #   ZOOM0012: zoom_offset = 0       → frame = shift
            #   ZOOM0013: zoom_offset = 34.5min → frame = 34.5*60*fps + shift
            #
            # ── Step 6a: compute global offset for every master ───────────
            master_offsets: Dict[str, tuple] = {}   # ap → (zoom_offset_sec, master_frame)
            for ap in self.audio_masters:
                best_cam_for_master = None
                best_q = 0
                for cam_name in self.camera_timelines:
                    key = (cam_name, ap)
                    q   = cluster_quality.get(key, 0)
                    if q > best_q and cam_name in cam_reference_time:
                        best_q              = q
                        best_cam_for_master = cam_name

                if best_cam_for_master is not None:
                    zoom_start   = zoom_start_times[(best_cam_for_master, ap)]
                    ref_time     = cam_reference_time[best_cam_for_master]
                    zoom_offset  = (zoom_start - ref_time).total_seconds()
                    master_frame = int(zoom_offset * fps) + timeline_shift_frames
                    self.progress.emit(self.t("log_master_placed",
                        name=Path(ap).name, min=zoom_offset/60, frame=master_frame))
                else:
                    zoom_offset  = 0.0
                    master_frame = timeline_shift_frames
                    self.progress.emit(self.t("log_master_no_cluster",
                        name=Path(ap).name))
                master_offsets[ap] = (zoom_offset, master_frame)

            # ── Step 6b: classify masters as continuous vs parallel ──────
            self.progress.emit(self.t("log_master_relations"))

            master_durations: Dict[str, float] = {}
            for ap in self.audio_masters:
                meta = get_media_metadata(ap)
                dur  = meta.get("duration", 0.0)
                master_durations[ap] = dur

            OVERLAP_TOLERANCE_SEC = 10.0
            masters_sorted = sorted(
                self.audio_masters,
                key=lambda ap: master_offsets[ap][0]
            )

            has_parallel = False
            windows = []  # (start, end, ap)
            for ap in masters_sorted:
                s = master_offsets[ap][0]
                e = s + master_durations.get(ap, 0.0)
                for (s0, e0, _) in windows:
                    if s < e0 - OVERLAP_TOLERANCE_SEC and e > s0 + OVERLAP_TOLERANCE_SEC:
                        has_parallel = True
                        break
                windows.append((s, e, ap))

            if has_parallel:
                self.progress.emit(self.t("log_masters_parallel"))
            else:
                self.progress.emit(self.t("log_masters_continuous"))
            for ap in masters_sorted:
                dur = master_durations.get(ap, 0.0)
                s   = master_offsets[ap][0]
                self.progress.emit(self.t("log_master_window",
                    name=Path(ap).name, s=s/60, e=(s+dur)/60))

            # ── Step 6c: build audio_track_specs ──────────────────────────
            # ONE TRACK PER MASTER — continuous or parallel doesn't matter.
            # The editor wants every ZOOM file on its own layer for clarity.
            #
            # SKIP the virtual master: it's a camera clip already placed on
            # its camera's video track.  Adding it as a separate audio track
            # would duplicate its audio at the same timeline position.
            audio_track_specs = []
            track_idx = 0
            for ap in self.audio_masters:
                if ap == self.virtual_master_path:
                    continue
                track_idx += 1
                _, master_frame = master_offsets[ap]
                dur_sec         = master_durations.get(ap, 0.0)
                audio_track_specs.append({
                    "file_path":    ap,
                    "record_frame": max(0, master_frame),
                    "track_index":  track_idx,   # 1-based, bridge adds n_cams offset
                    "duration_sec": dur_sec,
                })

            if self.virtual_master_path:
                self.progress.emit(self.t("log_virtual_master_track",
                    name=Path(self.virtual_master_path).name))
            else:
                self.progress.emit(self.t("log_n_master_tracks",
                    n=len(audio_track_specs)))

            spec = {
                "name":          self.output_name,
                "fps":           fps,
                "camera_tracks": cam_track_specs,
                "audio_tracks":  audio_track_specs,
            }

            spec_file = "/tmp/cinematic_sync_spec.json"
            with open(spec_file, "w") as f:
                json.dump(spec, f, indent=2)

            # ── Step 7: create timeline in DaVinci ────────────────────────
            result = self.bridge_call("create_timeline", spec_file)
            if not result.get("success"):
                self.finished.emit(False, self.t("err_create_timeline",
                    err=result.get("error")))
                return

            errs = result.get("errors", [])
            if errs:
                self.progress.emit(self.t("log_warnings",
                    lines="\n".join(f"   • {e}" for e in errs)))

            # ── Done ──────────────────────────────────────────────────────
            def _bucket(m: str) -> str:
                if m.startswith("wf-cross"): return "wf-cross"
                if m.startswith("wf+ts"):    return "wf+ts"
                if m.startswith("wf"):       return "wf"
                if m.startswith("ts"):       return "ts"
                return "other"

            all_clips = [c for cam in cam_track_specs for c in cam["clips"]]
            buckets   = defaultdict(int)
            for c in all_clips:
                buckets[_bucket(c.get("method", ""))] += 1

            unknown_range = self.t("summary_unknown_range")
            summary_lines = []
            for cam in cam_track_specs:
                n        = len(cam["clips"])
                cam_buck = defaultdict(int)
                for c in cam["clips"]:
                    cam_buck[_bucket(c.get("method", ""))] += 1
                pos = [c["offset_sec"] for c in cam["clips"]]
                rng = f"{min(pos)/60:.1f}–{max(pos)/60:.1f} min" if pos else unknown_range
                summary_lines.append(self.t("summary_cam_line",
                    cam=cam['camera_name'], n=n, rng=rng,
                    wf=cam_buck['wf'], wfts=cam_buck['wf+ts'],
                    wfc=cam_buck['wf-cross'], ts=cam_buck['ts']))

            totals_line = (
                f"wf:{buckets['wf']}  wf+ts:{buckets['wf+ts']}  "
                f"wf-cross:{buckets['wf-cross']}  ts:{buckets['ts']}"
            )
            wf_total = buckets['wf'] + buckets['wf+ts'] + buckets['wf-cross']
            ts_total = buckets['ts']

            warning = ""
            if wf_total == 0 and ts_total > 0:
                warning = "\n\n" + self.t("summary_all_ts_warning")

            violet_count = result.get("violet_count", 0)
            violet_line  = ""
            if violet_count:
                violet_line = "\n" + self.t("summary_violet", n=violet_count) + "\n"

            self.finished.emit(
                True,
                self.t("summary_title", name=self.output_name) + "\n\n" +
                self.t("summary_methods", totals=totals_line) + "\n" +
                self.t("summary_methods_explain") +
                f"{violet_line}" +
                f"{warning}\n\n" +
                "\n".join(summary_lines)
            )

        except Exception as e:
            import traceback
            self.finished.emit(False, self.t("err_unhandled",
                err=str(e), tb=traceback.format_exc()))


class CinematicSyncGUI(QMainWindow):

    def __init__(self):
        super().__init__()
        self.selected_timelines = []
        self.selected_audio_masters = []   # now a list
        self.sync_worker = None
        self.all_audios = []
        self.project_name = None
        self.media_root = None
        self.media_clips = []

        self.setWindowTitle(tr("window_title"))
        self.setGeometry(100, 100, 1100, 680)
        self.setStyleSheet(DARK_STYLE)

        self.init_ui()
        self.load_data()

    def init_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        outer = QVBoxLayout(main_widget)
        outer.setContentsMargins(16, 16, 16, 16)
        outer.setSpacing(12)

        # ── Header ──────────────────────────────────────────────────────
        header = QHBoxLayout()
        self.title_lbl = QLabel(tr("header_title"))
        title_font = QFont()
        title_font.setBold(True)
        title_font.setPointSize(14)
        self.title_lbl.setFont(title_font)

        self.project_label = QLabel(tr("connecting"))
        self.project_label.setObjectName("statusLabel")
        self.project_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

        self.lang_btn = QPushButton(tr("btn_lang"))
        self.lang_btn.setFixedWidth(70)
        self.lang_btn.setToolTip(tr("btn_lang_tooltip"))
        self.lang_btn.clicked.connect(self.on_toggle_lang)

        self.refresh_btn = QPushButton(tr("btn_refresh"))
        self.refresh_btn.setFixedWidth(110)
        self.refresh_btn.clicked.connect(self.load_data)

        header.addWidget(self.title_lbl)
        header.addStretch()
        header.addWidget(self.project_label)
        header.addWidget(self.lang_btn)
        header.addWidget(self.refresh_btn)
        outer.addLayout(header)

        # ── Divider ──────────────────────────────────────────────────────
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("background-color: #2a2a2a;")
        line.setFixedHeight(1)
        outer.addWidget(line)

        # ── Main columns ─────────────────────────────────────────────────
        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(1)

        # LEFT: timelines
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 8, 0)

        self.tl_title = QLabel(tr("section_timelines"))
        self.tl_title.setObjectName("sectionTitle")
        lv.addWidget(self.tl_title)

        self.timeline_tree = QTreeWidget()
        self.timeline_tree.setHeaderLabel(tr("tree_header_timeline"))
        self.timeline_tree.itemClicked.connect(self.on_timeline_clicked)
        lv.addWidget(self.timeline_tree)

        self.timeline_status = QLabel(tr("n_of_m_selected", n=0, m=0))
        self.timeline_status.setObjectName("statusLabel")
        lv.addWidget(self.timeline_status)

        # RIGHT: audio
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(8, 0, 0, 0)

        self.audio_title = QLabel(tr("section_audio_masters"))
        self.audio_title.setObjectName("sectionTitle")
        rv.addWidget(self.audio_title)

        self.audio_list = QTreeWidget()
        self.audio_list.setHeaderLabel(tr("tree_header_file"))
        self.audio_list.itemClicked.connect(self.on_audio_clicked)
        rv.addWidget(self.audio_list)

        self.audio_status = QLabel(tr("audios_searching"))
        self.audio_status.setObjectName("statusLabel")
        rv.addWidget(self.audio_status)

        self.browse_btn = QPushButton(tr("btn_browse"))
        self.browse_btn.clicked.connect(self.browse_audio)
        rv.addWidget(self.browse_btn)

        splitter.addWidget(left)
        splitter.addWidget(right)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 1)
        outer.addWidget(splitter, stretch=3)

        # ── Bottom ───────────────────────────────────────────────────────
        bottom = QVBoxLayout()
        bottom.setSpacing(8)

        out_row = QHBoxLayout()
        self.out_lbl = QLabel(tr("output_timeline"))
        self.out_lbl.setFixedWidth(130)
        self.output_name = QLineEdit(tr("default_out_name"))
        out_row.addWidget(self.out_lbl)
        out_row.addWidget(self.output_name)
        bottom.addLayout(out_row)

        self.log_label = QLabel(tr("ready_to_sync"))
        self.log_label.setObjectName("logLabel")
        self.log_label.setMinimumHeight(70)
        self.log_label.setWordWrap(True)
        self.log_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        bottom.addWidget(self.log_label)

        btn_row = QHBoxLayout()
        self.sync_btn = QPushButton(tr("btn_sync"))
        self.sync_btn.setObjectName("syncBtn")
        self.sync_btn.clicked.connect(self.on_sync)

        self.clear_btn = QPushButton(tr("btn_clear"))
        self.clear_btn.clicked.connect(self.on_clear)
        self.clear_btn.setFixedWidth(100)

        self.exit_btn = QPushButton(tr("btn_exit"))
        self.exit_btn.clicked.connect(self.close)
        self.exit_btn.setFixedWidth(80)

        btn_row.addWidget(self.sync_btn)
        btn_row.addWidget(self.clear_btn)
        btn_row.addWidget(self.exit_btn)
        bottom.addLayout(btn_row)

        outer.addLayout(bottom, stretch=1)

    # ── Language toggle ──────────────────────────────────────────────────
    def on_toggle_lang(self):
        new_lang = "en" if CURRENT_LANG == "es" else "es"
        set_lang(new_lang)
        self.retranslate_ui()
        # Reload the data so any dynamic strings (project label, etc.) refresh.
        self.load_data()

    def retranslate_ui(self):
        """Update every visible string after a language switch."""
        self.setWindowTitle(tr("window_title"))
        self.title_lbl.setText(tr("header_title"))
        self.lang_btn.setText(tr("btn_lang"))
        self.lang_btn.setToolTip(tr("btn_lang_tooltip"))
        self.refresh_btn.setText(tr("btn_refresh"))
        self.tl_title.setText(tr("section_timelines"))
        self.timeline_tree.setHeaderLabel(tr("tree_header_timeline"))
        self.audio_title.setText(tr("section_audio_masters"))
        self.audio_list.setHeaderLabel(tr("tree_header_file"))
        self.browse_btn.setText(tr("btn_browse"))
        self.out_lbl.setText(tr("output_timeline"))
        self.sync_btn.setText(tr("btn_sync"))
        self.clear_btn.setText(tr("btn_clear"))
        self.exit_btn.setText(tr("btn_exit"))
        # Refresh status labels with their current data
        self.update_timeline_status()
        self.refresh_selected_audio()
        # Reset the log label only if it still has the default text
        cur = self.log_label.text()
        if cur in (TRANSLATIONS["es"]["ready_to_sync"],
                   TRANSLATIONS["en"]["ready_to_sync"]):
            self.log_label.setText(tr("ready_to_sync"))

    # ── Data loading ─────────────────────────────────────────────────────

    def load_data(self):
        self.load_timelines()
        self.load_audio_files()

    def load_timelines(self):
        self.timeline_tree.clear()
        self.selected_timelines = []

        project_name, timelines, media_root, clips, bridge_error = get_davinci_timelines()
        self.media_root  = media_root
        self.media_clips = clips

        if project_name and timelines:
            self.project_name = project_name
            self.project_label.setText(f"📽  {project_name}")
            self.project_label.setStyleSheet("color: #5ac85a; font-size: 11px;")

            # Group under project name
            root = QTreeWidgetItem([f"📁  {project_name}"])
            root_font = QFont()
            root_font.setBold(True)
            root.setFont(0, root_font)
            self.timeline_tree.addTopLevelItem(root)

            for tl_name in timelines:
                child = QTreeWidgetItem([tl_name])
                child.setCheckState(0, Qt.Unchecked)
                root.addChild(child)

            self.timeline_tree.expandAll()
            self.log_label.setText(tr("n_timelines_loaded", n=len(timelines), name=project_name))

        else:
            # DaVinci not connected — show message with actual error
            error_detail = bridge_error or "Unknown"
            self.project_label.setText(tr("davinci_not_connected"))
            self.project_label.setStyleSheet("color: #e0a030; font-size: 11px;")
            msg = QTreeWidgetItem([tr("davinci_not_detected")])
            msg.setForeground(0, QColor("#e0a030"))
            self.timeline_tree.addTopLevelItem(msg)
            hint = QTreeWidgetItem([f"Error: {error_detail}"])
            hint.setForeground(0, QColor("#cc6666"))
            self.timeline_tree.addTopLevelItem(hint)
            hint2 = QTreeWidgetItem([tr("davinci_open_hint")])
            hint2.setForeground(0, QColor("#888"))
            self.timeline_tree.addTopLevelItem(hint2)
            self.log(f"{tr('davinci_connect_log')} | {error_detail}")

        self.update_timeline_status()

    def load_audio_files(self):
        self.audio_list.clear()
        self.selected_audio_masters = []
        self.all_audios = find_audio_files(self.media_root)

        if self.all_audios:
            # Group by parent folder (e.g. ZOOM0009, ZOOM0010…)
            groups = {}
            for audio in self.all_audios:
                folder = Path(audio['folder']).name
                groups.setdefault(folder, []).append(audio)

            for folder_name, audios in sorted(groups.items()):
                group_item = QTreeWidgetItem([f"📁  {folder_name}"])
                gf = QFont(); gf.setBold(True)
                group_item.setFont(0, gf)
                group_item.setForeground(0, QColor("#aaa"))
                self.audio_list.addTopLevelItem(group_item)

                for audio in sorted(audios, key=lambda x: x['name'].lower()):
                    child = QTreeWidgetItem([f"  🎙  {audio['name']}"])
                    child.setData(0, Qt.UserRole, audio['path'])
                    child.setCheckState(0, Qt.Unchecked)
                    child.setToolTip(0, audio['path'])
                    group_item.addChild(child)

                group_item.setExpanded(True)

            self.audio_status.setText(tr("n_audios_in_project", n=len(self.all_audios)))
        elif self.media_root:
            item = QTreeWidgetItem([tr("no_audio_found", path=self.media_root)])
            item.setForeground(0, QColor("#e0a030"))
            self.audio_list.addTopLevelItem(item)
            self.audio_status.setText(tr("use_browse_manual"))
        else:
            item = QTreeWidgetItem([tr("no_project_path")])
            item.setForeground(0, QColor("#e0a030"))
            self.audio_list.addTopLevelItem(item)
            hint = QTreeWidgetItem([tr("press_refresh_with_open")])
            hint.setForeground(0, QColor("#888"))
            self.audio_list.addTopLevelItem(hint)
            self.audio_status.setText(tr("use_browse_manual"))

    # ── Interactions ─────────────────────────────────────────────────────

    def on_timeline_clicked(self, item):
        if item.childCount() == 0 and item.checkState(0) is not None:
            new = Qt.Checked if item.checkState(0) == Qt.Unchecked else Qt.Unchecked
            item.setCheckState(0, new)
            self.refresh_selected_timelines()

    def refresh_selected_timelines(self):
        self.selected_timelines = []
        for i in range(self.timeline_tree.topLevelItemCount()):
            parent = self.timeline_tree.topLevelItem(i)
            for j in range(parent.childCount()):
                child = parent.child(j)
                if child.checkState(0) == Qt.Checked:
                    self.selected_timelines.append(child.text(0).strip())
        self.update_timeline_status()

    def update_timeline_status(self):
        total = 0
        for i in range(self.timeline_tree.topLevelItemCount()):
            total += self.timeline_tree.topLevelItem(i).childCount()
        self.timeline_status.setText(tr("n_of_m_selected", n=len(self.selected_timelines), m=total))

    def on_audio_clicked(self, item):
        if item.childCount() == 0:  # leaf node
            new = Qt.Checked if item.checkState(0) == Qt.Unchecked else Qt.Unchecked
            item.setCheckState(0, new)
            self.refresh_selected_audio()

    def refresh_selected_audio(self):
        self.selected_audio_masters = []
        for i in range(self.audio_list.topLevelItemCount()):
            parent = self.audio_list.topLevelItem(i)
            for j in range(parent.childCount()):
                child = parent.child(j)
                if child.checkState(0) == Qt.Checked:
                    path = child.data(0, Qt.UserRole)
                    if path:
                        self.selected_audio_masters.append(path)
        n = len(self.selected_audio_masters)
        if n:
            self.audio_status.setText(tr("n_masters_selected", n=n))
            self.audio_status.setStyleSheet("color: #5ac85a; font-size: 10px;")
        else:
            self.audio_status.setText(tr("select_one_or_more"))
            self.audio_status.setStyleSheet("color: #888; font-size: 10px;")

    def browse_audio(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, tr("browse_dialog_title"),
            str(Path.home()),
            tr("browse_filter"),
        )
        if not paths:
            return

        # Find or create "Manual" group in audio list
        manual_root = None
        for i in range(self.audio_list.topLevelItemCount()):
            if "Manual" in self.audio_list.topLevelItem(i).text(0):
                manual_root = self.audio_list.topLevelItem(i)
                break
        if not manual_root:
            manual_root = QTreeWidgetItem([tr("manual_group")])
            f = QFont(); f.setBold(True)
            manual_root.setFont(0, f)
            manual_root.setForeground(0, QColor("#888"))
            self.audio_list.insertTopLevelItem(0, manual_root)
            manual_root.setExpanded(True)

        for path in paths:
            name = Path(path).name
            child = QTreeWidgetItem([f"  🎙  {name}"])
            child.setData(0, Qt.UserRole, path)
            child.setCheckState(0, Qt.Checked)
            child.setForeground(0, QColor("#5ac85a"))
            child.setToolTip(0, path)
            manual_root.addChild(child)

        self.refresh_selected_audio()


    # ── Sync ─────────────────────────────────────────────────────────────

    def on_sync(self):
        if not self.selected_timelines:
            QMessageBox.warning(self, tr("dlg_no_selection_title"),
                                tr("dlg_no_selection_body"))
            return

        # Virtual-master fallback: if no external audio is selected, offer
        # to use the longest camera clip as the audio reference.
        use_virtual_master = False
        if not self.selected_audio_masters:
            reply = QMessageBox.question(
                self,
                tr("dlg_no_master_title"),
                tr("dlg_no_master_body"),
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes,
            )
            if reply != QMessageBox.Yes:
                return
            use_virtual_master = True

        out = self.output_name.text().strip() or tr("default_out_name")
        self.sync_btn.setEnabled(False)
        if use_virtual_master:
            self.log(tr("log_sync_starting", n=len(self.selected_timelines)))
        else:
            self.log(tr("log_sync_starting_real",
                        n=len(self.selected_timelines),
                        m=len(self.selected_audio_masters)))

        self.sync_worker = SyncWorker(
            self.selected_timelines, self.selected_audio_masters, out,
            python_cmd=sys.executable,
            use_virtual_master=use_virtual_master,
            lang=CURRENT_LANG,
        )
        self.sync_worker.progress.connect(self.log)
        self.sync_worker.finished.connect(self.on_sync_done)
        self.sync_worker.start()

    def on_sync_done(self, success, message):
        self.sync_btn.setEnabled(True)
        if success:
            QMessageBox.information(self, tr("dlg_success_title"), message)
        else:
            QMessageBox.critical(self, tr("dlg_error_title"), message)
        self.log(message)

    def on_clear(self):
        for i in range(self.timeline_tree.topLevelItemCount()):
            parent = self.timeline_tree.topLevelItem(i)
            for j in range(parent.childCount()):
                parent.child(j).setCheckState(0, Qt.Unchecked)
        for i in range(self.audio_list.topLevelItemCount()):
            parent = self.audio_list.topLevelItem(i)
            for j in range(parent.childCount()):
                parent.child(j).setCheckState(0, Qt.Unchecked)
        self.selected_timelines = []
        self.selected_audio_masters = []
        self.output_name.setText(tr("default_out_name"))
        self.audio_status.setStyleSheet("")
        self.audio_status.setText(tr("select_one_or_more"))
        self.update_timeline_status()
        self.log(tr("ready_to_sync"))

    # ── Log ───────────────────────────────────────────────────────────────

    def log(self, message):
        current = self.log_label.text()
        # Detect "ready to sync" placeholder in either language so the first
        # real log line replaces it instead of being appended to it.
        ready_strs = (TRANSLATIONS["es"]["ready_to_sync"],
                      TRANSLATIONS["en"]["ready_to_sync"])
        if any(r in current for r in ready_strs):
            self.log_label.setText(message)
        else:
            lines = current.split("\n")[-6:]  # keep last 6 lines
            lines.append(message)
            self.log_label.setText("\n".join(lines))


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    window = CinematicSyncGUI()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    main()
