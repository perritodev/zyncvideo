@echo off
setlocal enabledelayedexpansion
title Zync - Windows Setup

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║         Zync - DaVinci Resolve Sync          ║
echo  ║              Windows Installer               ║
echo  ╚══════════════════════════════════════════════╝
echo.

:: ── 1. Find Python ────────────────────────────────────────────────────────────
echo [1/4] Looking for Python 3.10...

set PYTHON_CMD=
for %%P in (
    "py -3.10"
    "python3.10"
    "python"
    "python3"
) do (
    if not defined PYTHON_CMD (
        %%~P --version >nul 2>&1
        if !errorlevel! == 0 (
            for /f "tokens=2" %%V in ('%%~P --version 2^>^&1') do set PY_VER=%%V
            set PYTHON_CMD=%%~P
        )
    )
)

if not defined PYTHON_CMD (
    echo.
    echo  [ERROR] Python not found.
    echo.
    echo  DaVinci Resolve scripting requires Python 3.10.
    echo  Download it from: https://www.python.org/downloads/release/python-31011/
    echo  Make sure to check "Add Python to PATH" during install.
    echo.
    pause
    exit /b 1
)
echo  [OK] Found Python: %PYTHON_CMD% ^(%PY_VER%^)

:: ── 2. Install Python packages ─────────────────────────────────────────────────
echo.
echo [2/4] Installing required packages...
%PYTHON_CMD% -m pip install --quiet --upgrade PyQt5 librosa scipy numpy
if %errorlevel% neq 0 (
    echo  [ERROR] Failed to install packages.
    pause
    exit /b 1
)
echo  [OK] Packages installed.

:: ── 3. Copy files to AppData ──────────────────────────────────────────────────
echo.
echo [3/4] Installing Zync...
set INSTALL_DIR=%APPDATA%\Zync
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
xcopy /S /Y /I "%~dp0*" "%INSTALL_DIR%\" >nul
echo  [OK] Files installed to %INSTALL_DIR%

:: ── 4. Create Desktop shortcut ────────────────────────────────────────────────
echo.
echo [4/4] Creating Desktop launcher...

:: Detect actual Desktop path from registry (handles OneDrive/custom paths)
set DESKTOP_PATH=
for /f "usebackq tokens=2,*" %%A in (`reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders" /v Desktop`) do (
    set DESKTOP_PATH=%%B
)
:: Expand environment variables in the path (like %USERPROFILE%)
for /f "delims=" %%i in ('echo %DESKTOP_PATH%') do set DESKTOP_PATH=%%i

if not defined DESKTOP_PATH set DESKTOP_PATH=%USERPROFILE%\Desktop

set LAUNCHER=%DESKTOP_PATH%\Zync.bat
echo @echo off > "%LAUNCHER%"
echo cd /d "%INSTALL_DIR%" >> "%LAUNCHER%"
echo start "" %PYTHON_CMD% "launcher.py" >> "%LAUNCHER%"
echo  [OK] Desktop launcher created at: %LAUNCHER%

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║          Installation Complete!              ║
echo  ║                                              ║
echo  ║  1. Open DaVinci Resolve                    ║
echo  ║  2. Go to Preferences > General             ║
echo  ║  3. Set External Scripting to: Local        ║
echo  ║  4. Double-click the Zync icon on Desktop   ║
echo  ╚══════════════════════════════════════════════╝
echo.
pause
