#!/usr/bin/env python3
"""
DaVinci Resolve Bridge — full two-way control via scripting API.
Called as a subprocess by the GUI. Outputs JSON to stdout.

Commands:
  all               — project info + timelines + media pool
  timeline_clips    — clips from a specific timeline (arg: timeline_name)
  create_timeline   — create multicam timeline from JSON spec (arg: spec_file)
  delete_timelines  — delete timelines by name (arg: names JSON array)
"""

import sys
import os
import json
from pathlib import Path

import platform

if platform.system() == "Darwin":
    FUSION_PATH = '/Applications/DaVinci Resolve/DaVinci Resolve.app/Contents/Libraries/Fusion'
    os.environ['DYLD_LIBRARY_PATH'] = FUSION_PATH + ':' + os.environ.get('DYLD_LIBRARY_PATH', '')
    os.environ['PYTHONPATH']        = FUSION_PATH + ':' + os.environ.get('PYTHONPATH', '')
elif platform.system() == "Windows":
    FUSION_PATH = os.path.expandvars(r"%PROGRAMDATA%\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting\Modules")
    RESOLVE_APP_PATH = r"C:\Program Files\Blackmagic Design\DaVinci Resolve"

    os.environ['RESOLVE_SCRIPT_API'] = os.path.expandvars(r"%PROGRAMDATA%\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting")
    os.environ['RESOLVE_SCRIPT_LIB'] = os.path.join(RESOLVE_APP_PATH, "fusionscript.dll")
    os.environ['PYTHONHOME'] = sys.base_prefix

    # Windows: add DLL search directory so ctypes can find fusionscript.dll dependencies
    os.environ['PATH'] = RESOLVE_APP_PATH + os.pathsep + os.environ.get('PATH', '')
    os.environ['PYTHONPATH'] = FUSION_PATH + os.pathsep + os.environ.get('PYTHONPATH', '')
    try:
        os.add_dll_directory(RESOLVE_APP_PATH)
    except (AttributeError, OSError):
        pass
else:
    FUSION_PATH = '/opt/resolve/libs/Fusion'
    os.environ['PYTHONPATH'] = FUSION_PATH + ':' + os.environ.get('PYTHONPATH', '')

if FUSION_PATH not in sys.path:
    sys.path.insert(0, FUSION_PATH)


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_all_media_pool_items(folder, result=None):
    """Recursively collect all MediaPoolItem objects keyed by file path"""
    if result is None:
        result = {}
    try:
        clips = folder.GetClipList()
        if clips:
            for c in clips:
                try:
                    fp = c.GetClipProperty("File Path")
                    if fp:
                        result[fp] = c
                except Exception:
                    pass
    except Exception:
        pass
    try:
        subs = folder.GetSubFolderList()
        if subs:
            for sf in subs:
                get_all_media_pool_items(sf, result)
    except Exception:
        pass
    return result


def find_timeline(project, name):
    count = project.GetTimelineCount()
    for i in range(1, count + 1):
        tl = project.GetTimelineByIndex(i)
        if tl and tl.GetName() == name:
            return tl
    return None


def timeline_fps(tl):
    try:
        fps = tl.GetSetting("timelineFrameRate")
        return float(fps) if fps else 23.976
    except Exception:
        return 23.976


# ── Commands ──────────────────────────────────────────────────────────────────

def cmd_all(project):
    result = {"success": True, "project_name": project.GetName()}

    # Timelines
    timelines = []
    count = project.GetTimelineCount()
    for i in range(1, count + 1):
        tl = project.GetTimelineByIndex(i)
        if tl:
            timelines.append({
                "name":              tl.GetName(),
                "start_tc":         tl.GetStartTimecode(),
                "fps":               timeline_fps(tl),
                "track_count_video": tl.GetTrackCount("video"),
                "track_count_audio": tl.GetTrackCount("audio"),
            })
    result["timelines"] = timelines

    # Media root from first real clip
    media_root = None
    try:
        mp   = project.GetMediaPool()
        root = mp.GetRootFolder()
        items = get_all_media_pool_items(root)
        for fp in items:
            if fp:
                p = Path(fp)
                if p.is_absolute():
                    parts = p.parts
                    if platform.system() == "Windows":
                        media_root = str(Path(*parts[:2])) if len(parts) >= 2 else str(p.parent)
                    elif fp.startswith("/Volumes"):
                        media_root = str(Path(*parts[:4])) if len(parts) >= 4 else str(Path(*parts[:3]))
                    else:
                        media_root = str(Path(*parts[:4])) if len(parts) >= 4 else str(p.parent)
                    break
    except Exception as e:
        result["media_pool_error"] = str(e)

    result["media_root"] = media_root
    return result


def cmd_timeline_clips(project, timeline_name):
    tl = find_timeline(project, timeline_name)
    if not tl:
        return {"success": False, "error": f"Timeline '{timeline_name}' not found"}

    fps   = timeline_fps(tl)
    items = []
    try:
        v_tracks = tl.GetTrackCount("video")
        for t in range(1, v_tracks + 1):
            clip_list = tl.GetItemListInTrack("video", t)
            if not clip_list:
                continue
            for ci in clip_list:
                try:
                    mpi = ci.GetMediaPoolItem()
                    if not mpi:
                        continue
                    props = mpi.GetClipProperty()
                    items.append({
                        "name":             props.get("Clip Name", ""),
                        "file_path":        props.get("File Path", ""),
                        "directory":        props.get("Clip Directory", ""),
                        "type":             props.get("Type", ""),
                        "fps":              fps,
                        "timeline_start":   ci.GetStart(),
                        "timeline_end":     ci.GetEnd(),
                        "duration_frames":  ci.GetDuration(),
                        "source_start":     ci.GetLeftOffset(),
                        "timecode":         props.get("Start TC", ""),
                        "date_created":     props.get("Date Created", ""),
                        "track":            t,
                    })
                except Exception as e:
                    items.append({"error": str(e)})
    except Exception as e:
        return {"success": False, "error": str(e)}

    return {"success": True, "timeline": timeline_name, "fps": fps, "clips": items}


def cmd_create_timeline(project, spec_file):
    """
    spec = {
        "name": "FINAL_SYNC",
        "fps":  23.976,
        "camera_tracks": [
            {
                "camera_name": "CANON",
                "track_index": 1,
                "clips": [
                    {
                        "file_path": "/Volumes/.../clip.mp4",
                        "record_frame": 120,      # where to place on timeline
                        "source_start": 0,
                        "duration_frames": 500
                    }
                ]
            }
        ],
        "audio_tracks": [
            {
                "file_path": "/Volumes/.../ZOOM0014_TrLR.WAV",
                "record_frame": 0,
                "track_index": 1
            }
        ]
    }
    """
    try:
        with open(spec_file) as f:
            spec = json.load(f)
    except Exception as e:
        return {"success": False, "error": f"Cannot read spec file: {e}"}

    name = spec.get("name", "ZYNC_SYNC")
    fps  = spec.get("fps", 23.976)

    try:
        mp   = project.GetMediaPool()
        root = mp.GetRootFolder()
        all_items = get_all_media_pool_items(root)

        # Import any files (audio or video) that aren't in the media pool yet
        paths_to_import = []
        for at in spec.get("audio_tracks", []):
            fp = at.get("file_path", "")
            if fp and fp not in all_items:
                paths_to_import.append(fp)
                
        for cam in spec.get("camera_tracks", []):
            for clip in cam.get("clips", []):
                fp = clip.get("file_path", "")
                if fp and fp not in all_items:
                    paths_to_import.append(fp)

        if paths_to_import:
            imported = mp.ImportMedia(paths_to_import)
            if imported:
                for imp in imported:
                    try:
                        fp = imp.GetClipProperty("File Path")
                        if fp:
                            all_items[fp] = imp
                    except Exception:
                        pass

        # If a timeline with this name already exists, delete it first so
        # CreateEmptyTimeline doesn't refuse to create a duplicate.
        existing = find_timeline(project, name)
        if existing:
            mp.DeleteTimelines([existing])

        # Create empty timeline
        tl_obj = mp.CreateEmptyTimeline(name)
        if not tl_obj:
            # Fallback: try with a timestamped name to avoid any lingering conflict
            import time as _time
            name = f"{name}_{int(_time.time()) % 10000}"
            tl_obj = mp.CreateEmptyTimeline(name)
            if not tl_obj:
                return {"success": False, "error": "CreateEmptyTimeline failed — DaVinci refused to create the timeline. Make sure a project is open and try a different name."}

        project.SetCurrentTimeline(tl_obj)
        tl = project.GetCurrentTimeline()

        # Reset start timecode to 00:00:00:00 so recordFrame=0 maps to frame 0
        try:
            tl.SetStartTimecode("00:00:00:00")
        except Exception:
            pass

        # Force the new timeline's frame rate to match the GUI's calculations.
        # CreateEmptyTimeline inherits the project's default fps, which may not
        # match the source camera timelines or the spec's fps — that mismatch
        # causes proportional drift on every clip placement.  Setting it
        # explicitly here keeps `record_frame` math and timeline playback in
        # the same frame-rate space.
        try:
            tl.SetSetting("timelineFrameRate", str(fps))
        except Exception:
            pass

        # Add extra video tracks (one per camera)
        cam_tracks  = spec.get("camera_tracks", [])
        audio_tracks = spec.get("audio_tracks", [])
        existing_v  = tl.GetTrackCount("video")
        for _ in range(len(cam_tracks) - existing_v):
            tl.AddTrack("video")

        # Audio layout:
        #   A1..A(n_cams)          ← camera audio (linked to each video track)
        #   A(n_cams+1)..A(n_cams+n_zoom_tracks)  ← ZOOM master audio
        #
        # track_index in audio_track_specs is 1-based *relative* to the ZOOM
        # block (set by the GUI's interval-scheduling logic):
        #   1   → continuous masters that share one track
        #   1,2 → two parallel master streams that must be on separate tracks
        # We offset each by n_cams so they sit after the camera audio tracks.
        n_cams       = len(cam_tracks)
        # Number of distinct ZOOM tracks required (max relative track index).
        # If audio_tracks is empty (virtual-master mode: the master is itself
        # a camera clip and was excluded), we don't need any extra ZOOM tracks.
        n_zoom_tracks = max((at.get("track_index", 1) for at in audio_tracks), default=0)
        total_audio   = n_cams + n_zoom_tracks      # e.g. 3 cams + 2 parallel ZOOMs = 5
        existing_a    = tl.GetTrackCount("audio")
        for _ in range(total_audio - existing_a):
            tl.AddTrack("audio")

        # Offset ZOOM track indices to sit AFTER the camera audio tracks
        for at in audio_tracks:
            at["track_index"] = n_cams + at.get("track_index", 1)

        errors          = []
        violet_count    = 0   # clips colored as "not waveform-synced"

        # Place video clips
        for cam in cam_tracks:
            ti = cam.get("track_index", 1)
            for clip in cam.get("clips", []):
                fp = clip.get("file_path", "")
                mpi = all_items.get(fp)
                if not mpi:
                    errors.append(f"Clip not in media pool: {fp}")
                    continue
                try:
                    clip_info = {
                        "mediaPoolItem": mpi,
                        "startFrame":    clip.get("source_start", 0),
                        "endFrame":      clip.get("source_start", 0) + clip.get("duration_frames", 100) - 1,
                        "recordFrame":   max(0, clip.get("record_frame", 0)),
                        "trackIndex":    ti,
                        # no mediaType → DaVinci includes both video AND camera audio
                    }
                    placed = mp.AppendToTimeline([clip_info])

                    # Color clips that did NOT use waveform sync (purely timestamp,
                    # or waveform was rejected for being inconsistent with ts).
                    # Methods starting with "ts" are exactly those — anything
                    # starting with "wf" used waveform truth.
                    method = clip.get("method", "")
                    if placed and method.startswith("ts"):
                        for item in placed:
                            try:
                                # "Violet" is one of DaVinci's named clip colors
                                # (Orange, Apricot, Yellow, Lime, Olive, Green,
                                # Teal, Navy, Blue, Purple, Violet, Pink, Tan,
                                # Beige, Brown, Chocolate)
                                item.SetClipColor("Violet")
                                violet_count += 1
                            except Exception:
                                pass
                except Exception as e:
                    errors.append(f"Cannot place {Path(fp).name}: {e}")

        # Place audio masters
        for at in audio_tracks:
            fp  = at.get("file_path", "")
            mpi = all_items.get(fp)
            if not mpi:
                errors.append(f"Audio not in media pool: {fp}")
                continue
            try:
                src_start = max(0, int(at.get("source_start", 0)))

                # Prefer duration_sec provided by the GUI (from ffprobe).
                # GetClipProperty("Frames") is unreliable for WAV files — it can
                # return the sample count rather than frames, or fall back to 0,
                # both of which produce an absurdly long clip on the timeline.
                dur_sec = at.get("duration_sec", 0.0)
                if dur_sec and dur_sec > 0:
                    end_frame = src_start + int(dur_sec * fps) - 1
                else:
                    # Last resort: ask DaVinci, but cap at something sane (6 hours)
                    raw = mpi.GetClipProperty("Frames")
                    end_frame = src_start + int(raw) - 1 if raw else src_start + int(6 * 3600 * fps)

                clip_info = {
                    "mediaPoolItem": mpi,
                    "startFrame":    src_start,
                    "endFrame":      max(src_start, end_frame),
                    "recordFrame":   max(0, int(at.get("record_frame", 0))),
                    "trackIndex":    int(at.get("track_index", 1)),
                    "mediaType":     2,  # audio
                }
                mp.AppendToTimeline([clip_info])
            except Exception as e:
                errors.append(f"Cannot place audio {Path(fp).name}: {e}")

        return {"success": True, "timeline": name,
                "errors": errors, "violet_count": violet_count}

    except Exception as e:
        return {"success": False, "error": str(e)}


def cmd_delete_timelines(project, names):
    """Only deletes timelines created by Zync (prefixed with CS_TEMP_)"""
    mp = project.GetMediaPool()
    deleted = []
    errors  = []
    for name in names:
        if not name.startswith("CS_TEMP_"):
            errors.append(f"Skipped '{name}': only CS_TEMP_ timelines can be deleted")
            continue
        try:
            tl = find_timeline(project, name)
            if tl:
                mp.DeleteTimelines([tl])
                deleted.append(name)
            else:
                errors.append(f"Not found: {name}")
        except Exception as e:
            errors.append(f"{name}: {e}")
    return {"success": True, "deleted": deleted, "errors": errors}


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("command", nargs="?", default="all")
    parser.add_argument("arg2", nargs="?", default=None)
    parser.add_argument("--out_file", type=str, default=None)
    args, unknown = parser.parse_known_args()

    command = args.command
    arg2 = args.arg2
    out_file = args.out_file

    def output_result(data):
        if out_file:
            with open(out_file, "w", encoding="utf-8") as f:
                json.dump(data, f)
        else:
            print(json.dumps(data))
        sys.exit(0 if data.get("success") else 1)

    # Top-level crash catcher — ensures we ALWAYS write something to out_file
    try:
        _run_main(command, arg2, output_result)
    except Exception as e:
        import traceback
        output_result({"success": False, "error": f"Bridge crash: {e}\n{traceback.format_exc(limit=5)}"})


def _run_main(command, arg2, output_result):
    try:
        import fusionscript as bmd
    except ImportError:
        try:
            import DaVinciResolveScript as bmd
        except ImportError as e:
            output_result({"success": False, "error": f"Cannot import DaVinci API: {e}. FUSION_PATH={FUSION_PATH}"})
            return

    try:
        resolve = bmd.scriptapp("Resolve")
        if not resolve:
            output_result({"success": False, "error": "DaVinci not running or External Scripting not enabled (set to Local in Preferences > General)"})
            return
    except Exception as e:
        output_result({"success": False, "error": f"scriptapp error: {e}"})
        return

    try:
        pm      = resolve.GetProjectManager()
        project = pm.GetCurrentProject()
        if not project:
            output_result({"success": False, "error": "No project open in DaVinci"})
            return
    except Exception as e:
        output_result({"success": False, "error": f"GetCurrentProject error: {e}"})
        return

    if command == "all":
        result = cmd_all(project)
    elif command == "timeline_clips":
        result = cmd_timeline_clips(project, arg2)
    elif command == "create_timeline":
        result = cmd_create_timeline(project, arg2)
    elif command == "delete_timelines":
        names  = json.loads(arg2) if arg2 else []
        result = cmd_delete_timelines(project, names)
    else:
        result = {"success": False, "error": f"Unknown command: {command}"}

    output_result(result)


if __name__ == "__main__":
    main()
