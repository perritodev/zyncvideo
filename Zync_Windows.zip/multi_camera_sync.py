#!/usr/bin/env python3
"""
Multi-Camera Audio Synchronization Script for DaVinci Resolve
Synchronizes multiple camera timelines with master audio using waveform analysis
and creation timestamp fallback for clips that can't be synced by waveform.
"""

import os
import sys
import json
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import subprocess
import datetime

# Try to import audio analysis libraries
try:
    import librosa
    import numpy as np
    from scipy.signal import correlate
    AUDIO_LIBS_AVAILABLE = True
except ImportError:
    AUDIO_LIBS_AVAILABLE = False
    print("⚠️  Warning: librosa/scipy not available. Install with: pip install librosa scipy numpy")
    print("   Falling back to creation time-based sync for unsyncable clips.\n")


class MultiCameraSync:
    """Synchronizes multiple camera timelines with master audio"""

    def __init__(self):
        self.resolve = self._get_resolve()
        self.project = self.resolve.GetProjectManager().GetCurrentProject()
        self.media_pool = self.project.GetMediaPool()

    def _get_resolve(self):
        """Get DaVinci Resolve instance"""
        try:
            import DaVinciResolveScript as dvs
            resolve = dvs.scriptapp("Resolve")
            return resolve
        except Exception as e:
            print(f"❌ Error connecting to DaVinci Resolve: {e}")
            sys.exit(1)

    def list_timelines(self) -> List[str]:
        """List all available timelines"""
        timeline_count = self.project.GetTimelineCount()
        timelines = []
        for i in range(timeline_count):
            timeline = self.project.GetTimelineByIndex(i + 1)
            timelines.append(timeline.GetName())
        return timelines

    def get_timeline_by_name(self, name: str):
        """Get timeline object by name"""
        timeline_count = self.project.GetTimelineCount()
        for i in range(timeline_count):
            timeline = self.project.GetTimelineByIndex(i + 1)
            if timeline.GetName() == name:
                return timeline
        return None

    def get_timeline_clips(self, timeline) -> Dict[str, List]:
        """Extract video and audio clips from timeline"""
        clips = {
            "video": [],
            "audio": []
        }

        # Get video tracks
        video_count = timeline.GetTrackCount("video")
        for v_idx in range(1, video_count + 1):
            video_clips = timeline.GetItemListInTrack("video", v_idx)
            clips["video"].extend(video_clips)

        # Get audio tracks
        audio_count = timeline.GetTrackCount("audio")
        for a_idx in range(1, audio_count + 1):
            audio_clips = timeline.GetItemListInTrack("audio", a_idx)
            clips["audio"].extend(audio_clips)

        return clips

    def get_clip_metadata(self, clip) -> Dict:
        """Extract metadata from clip"""
        media_pool_item = clip.GetMediaPoolItem()
        if not media_pool_item:
            return {}

        metadata = {
            "name": media_pool_item.GetName(),
            "duration": clip.GetDuration(),
            "start": clip.GetStart(),
            "end": clip.GetEnd(),
            "media_id": media_pool_item.GetMediaId(),
        }

        # Try to get creation time from metadata
        clip_properties = media_pool_item.GetClipProperty()
        if clip_properties:
            metadata["properties"] = clip_properties

        return metadata

    def extract_audio_for_waveform(self, audio_clip, timeline) -> Optional[np.ndarray]:
        """Extract audio data from clip for waveform analysis"""
        if not AUDIO_LIBS_AVAILABLE:
            return None

        try:
            media_pool_item = audio_clip.GetMediaPoolItem()
            if not media_pool_item:
                return None

            # Get file path from media pool item
            media_properties = media_pool_item.GetClipProperty()
            if not media_properties or "File Path" not in media_properties:
                return None

            file_path = media_properties.get("File Path")
            if not file_path or not os.path.exists(file_path):
                return None

            # Load audio using librosa
            audio_data, sr = librosa.load(file_path, sr=None, mono=True)
            return audio_data

        except Exception as e:
            print(f"⚠️  Could not extract audio from {audio_clip}: {e}")
            return None

    def calculate_sync_offset_by_waveform(self,
                                         camera_audio: np.ndarray,
                                         master_audio: np.ndarray) -> Optional[float]:
        """Calculate sync offset using waveform cross-correlation"""
        if camera_audio is None or master_audio is None:
            return None

        try:
            # Normalize audio
            camera_audio = camera_audio / np.max(np.abs(camera_audio))
            master_audio = master_audio / np.max(np.abs(master_audio))

            # Use shorter section if needed to speed up correlation
            max_len = min(len(camera_audio), len(master_audio))
            if max_len > 48000 * 60:  # More than 1 minute
                camera_audio = camera_audio[:48000 * 60]
                master_audio = master_audio[:48000 * 60]

            # Cross-correlation
            correlation = correlate(master_audio, camera_audio, mode='valid')
            lag = np.argmax(correlation)

            # Return offset in seconds (assuming 48kHz)
            offset_samples = lag - len(master_audio) // 2
            offset_seconds = offset_samples / 48000.0

            return offset_seconds

        except Exception as e:
            print(f"⚠️  Waveform correlation failed: {e}")
            return None

    def get_clip_creation_time(self, clip) -> Optional[datetime.datetime]:
        """Extract creation time from clip metadata"""
        try:
            media_pool_item = clip.GetMediaPoolItem()
            if not media_pool_item:
                return None

            # Try to get from metadata
            metadata = media_pool_item.GetMetadata()
            if metadata:
                # Common metadata keys for creation time
                for key in ["Date Created", "Creation Date", "File Modified Time"]:
                    if key in metadata:
                        try:
                            return datetime.datetime.fromisoformat(metadata[key])
                        except:
                            pass

            return None
        except:
            return None

    def sync_camera_timeline(self,
                            camera_timeline_name: str,
                            master_audio_clip) -> Dict[str, any]:
        """Synchronize individual camera timeline with master audio"""

        print(f"\n📹 Synchronizing camera: {camera_timeline_name}")

        camera_timeline = self.get_timeline_by_name(camera_timeline_name)
        if not camera_timeline:
            print(f"❌ Timeline '{camera_timeline_name}' not found")
            return None

        camera_clips = self.get_timeline_clips(camera_timeline)
        master_audio_data = self.extract_audio_for_waveform(master_audio_clip, camera_timeline)

        sync_data = {
            "timeline_name": camera_timeline_name,
            "timeline_obj": camera_timeline,
            "clips": [],
            "master_audio": master_audio_clip
        }

        # Process video clips
        for video_clip in camera_clips["video"]:
            clip_meta = self.get_clip_metadata(video_clip)

            # Try waveform sync with corresponding audio in camera timeline
            offset_seconds = None
            sync_method = "none"

            if AUDIO_LIBS_AVAILABLE and camera_clips["audio"]:
                # Get first audio track from camera timeline
                camera_audio_data = self.extract_audio_for_waveform(
                    camera_clips["audio"][0], camera_timeline
                )
                if camera_audio_data is not None and master_audio_data is not None:
                    offset_seconds = self.calculate_sync_offset_by_waveform(
                        camera_audio_data, master_audio_data
                    )
                    if offset_seconds is not None:
                        sync_method = "waveform"
                        print(f"✅ Waveform sync: {clip_meta['name']} -> offset: {offset_seconds:.2f}s")

            # Fallback: use creation time
            if offset_seconds is None:
                clip_time = self.get_clip_creation_time(video_clip)
                master_time = self.get_clip_creation_time(master_audio_clip)

                if clip_time and master_time:
                    time_diff = (clip_time - master_time).total_seconds()
                    offset_seconds = time_diff
                    sync_method = "creation_time"
                    print(f"⏱️  Time-based sync: {clip_meta['name']} -> offset: {offset_seconds:.2f}s")
                else:
                    offset_seconds = 0
                    sync_method = "default"
                    print(f"⚠️  No sync data: {clip_meta['name']} -> offset: 0s (default)")

            sync_data["clips"].append({
                "clip_obj": video_clip,
                "metadata": clip_meta,
                "offset_seconds": offset_seconds,
                "sync_method": sync_method,
                "audio_clip": camera_clips["audio"][0] if camera_clips["audio"] else None
            })

        return sync_data

    def create_multicam_timeline(self,
                                sync_data_list: List[Dict],
                                output_timeline_name: str = "MULTICAM_SYNC") -> bool:
        """Create final multicam timeline with synchronized clips"""

        print(f"\n🎬 Creating multicam timeline: {output_timeline_name}")

        # Create new timeline
        new_timeline = self.media_pool.CreateEmptyTimeline(output_timeline_name)
        if not new_timeline:
            print(f"❌ Failed to create timeline '{output_timeline_name}'")
            return False

        self.project.SetCurrentTimeline(new_timeline)

        # Calculate timeline duration (find max end time)
        max_duration = 0
        for sync_data in sync_data_list:
            for clip_data in sync_data["clips"]:
                clip_end = clip_data["metadata"]["end"] + clip_data["offset_seconds"]
                if clip_end > max_duration:
                    max_duration = clip_end

        # Add video tracks (one per camera)
        for i in range(len(sync_data_list)):
            new_timeline.AddTrack("video")

        # Add audio tracks (master + one per camera)
        # Master audio track
        new_timeline.AddTrack("audio")
        # Per-camera audio tracks
        for i in range(len(sync_data_list)):
            new_timeline.AddTrack("audio")

        # Place clips on timeline
        for cam_idx, sync_data in enumerate(sync_data_list):
            video_track_idx = cam_idx + 1  # 1-indexed
            audio_track_idx = cam_idx + 2  # Master is 1, cameras start at 2

            print(f"\n  📺 Camera {cam_idx + 1}: {sync_data['timeline_name']}")

            for clip_data in sync_data["clips"]:
                # Calculate new position based on offset
                offset = clip_data["offset_seconds"]
                new_start = clip_data["metadata"]["start"] + offset

                # Add video clip
                video_clip = clip_data["clip_obj"]
                # Note: Actual placement depends on DaVinci API capabilities
                # This is simplified - you may need to adjust based on actual API
                print(f"    ✓ {clip_data['metadata']['name']} (offset: {offset:.2f}s, method: {clip_data['sync_method']})")

                # Add corresponding audio if available
                if clip_data["audio_clip"]:
                    print(f"      🔊 Audio track synced")

        # Add master audio to first audio track
        if sync_data_list and sync_data_list[0]["master_audio"]:
            print(f"\n  🎙️  Master audio placed on audio track 1")

        return True

    def run_interactive(self):
        """Run the sync process interactively"""

        print("=" * 60)
        print("🎬 MULTI-CAMERA AUDIO SYNCHRONIZATION")
        print("=" * 60)

        # List available timelines
        timelines = self.list_timelines()
        print(f"\n📋 Available timelines ({len(timelines)}):")
        for i, tl in enumerate(timelines, 1):
            print(f"  {i}. {tl}")

        # Get camera timelines
        print("\n📹 SELECT CAMERA TIMELINES")
        print("Enter timeline names (one per line, empty line to finish):")

        camera_timelines = []
        while True:
            name = input(f"  Camera {len(camera_timelines) + 1}: ").strip()
            if not name:
                break
            if name in timelines:
                camera_timelines.append(name)
            else:
                print(f"  ❌ Timeline '{name}' not found")

        if not camera_timelines:
            print("❌ No camera timelines selected")
            return

        # Get master audio timeline
        print("\n🎙️  SELECT MASTER AUDIO TIMELINE")
        master_audio_timeline_name = input("Enter master audio timeline name: ").strip()

        master_timeline = self.get_timeline_by_name(master_audio_timeline_name)
        if not master_timeline:
            print(f"❌ Timeline '{master_audio_timeline_name}' not found")
            return

        master_clips = self.get_timeline_clips(master_timeline)
        if not master_clips["audio"]:
            print("❌ No audio found in master timeline")
            return

        master_audio_clip = master_clips["audio"][0]

        # Get output timeline name
        print("\n📝 CONFIGURATION")
        output_name = input("Output timeline name (default: MULTICAM_SYNC): ").strip()
        if not output_name:
            output_name = "MULTICAM_SYNC"

        # Synchronize each camera
        sync_results = []
        for camera_name in camera_timelines:
            sync_result = self.sync_camera_timeline(camera_name, master_audio_clip)
            if sync_result:
                sync_results.append(sync_result)

        # Create multicam timeline
        if sync_results:
            success = self.create_multicam_timeline(sync_results, output_name)
            if success:
                print(f"\n✅ Multicam timeline '{output_name}' created successfully!")
                print("\n📊 Summary:")
                print(f"  • Cameras synchronized: {len(sync_results)}")
                print(f"  • Master audio: {master_audio_timeline_name}")
                print(f"  • Output timeline: {output_name}")
            else:
                print(f"\n❌ Failed to create output timeline")
        else:
            print("\n❌ No cameras were successfully synchronized")


def main():
    """Main entry point"""
    try:
        sync = MultiCameraSync()
        sync.run_interactive()
    except KeyboardInterrupt:
        print("\n\n⛔ Operation cancelled by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
