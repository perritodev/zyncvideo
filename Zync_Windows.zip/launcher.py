import os, sys; os.environ['PYTHONHOME'] = sys.base_prefix; import zync; zync.main()
